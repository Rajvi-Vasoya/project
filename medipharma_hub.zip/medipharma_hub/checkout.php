<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
requireCustomerLogin();

// Prices, stock and the prescription flag always come from the database
$cartInfo = getCartDetails($pdo);
$cart     = $cartInfo['items'];
if (empty($cart)) {
    redirect('medicines.php');
}

$total             = $cartInfo['total'];
$needsPrescription = $cartInfo['needs_rx'];
$prescriptionPath  = validPrescriptionPath();

$error = '';
$flash = takeFlash();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCsrf($_POST['csrf_token'] ?? '')) {
        $error = "Your session expired. Please try again.";
    } elseif (!empty($cartInfo['notices'])) {
        // Stock or availability changed since the cart was built: let the customer review it first
        $error = "Some items in your cart changed (see the notes below). Please review your order and place it again.";
    } elseif ($needsPrescription && $prescriptionPath === null) {
        // Checked on the server, so it cannot be skipped by editing the page in the browser
        $error = "Please upload your prescription before placing this order.";
    } else {
        try {
            $pdo->beginTransaction();

            // 1. Lock the medicine rows and re-check price, stock and prescription need
            $ids = array_keys($cart);
            $in  = implode(',', array_fill(0, count($ids), '?'));
            $lock = $pdo->prepare("SELECT id, name, price, stock, requires_prescription FROM medicines WHERE id IN ($in) FOR UPDATE");
            $lock->execute($ids);
            $fresh = [];
            foreach ($lock->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $fresh[(int)$row['id']] = $row;
            }

            $orderTotal = 0.0;
            $rxInOrder  = false;
            foreach ($cart as $medicineId => $item) {
                if (!isset($fresh[$medicineId]) || (int)$fresh[$medicineId]['stock'] < $item['qty']) {
                    throw new RuntimeException('Sorry, "' . $item['name'] . '" does not have enough stock for your quantity. Please review your cart.');
                }
                $orderTotal += (float)$fresh[$medicineId]['price'] * $item['qty'];
                if ((int)$fresh[$medicineId]['requires_prescription'] === 1) { $rxInOrder = true; }
            }
            if ($rxInOrder && $prescriptionPath === null) {
                throw new RuntimeException('Please upload your prescription before placing this order.');
            }

            // 2. Create the order (the prescription is attached only when the order needs one)
            $stmt = $pdo->prepare(
                "INSERT INTO orders (user_id, total_amount, prescription_path, status) VALUES (?, ?, ?, 'pending')"
            );
            $stmt->execute([
                $_SESSION['user_id'],
                round($orderTotal, 2),
                $rxInOrder ? $prescriptionPath : null
            ]);
            $orderId = $pdo->lastInsertId();

            // 3. Insert each order item (database price) and reduce stock
            $itemStmt  = $pdo->prepare("INSERT INTO order_items (order_id, medicine_id, quantity, price) VALUES (?, ?, ?, ?)");
            $stockStmt = $pdo->prepare("UPDATE medicines SET stock = stock - ? WHERE id = ? AND stock >= ?");

            foreach ($cart as $medicineId => $item) {
                $itemStmt->execute([$orderId, $medicineId, $item['qty'], $fresh[$medicineId]['price']]);
                $stockStmt->execute([$item['qty'], $medicineId, $item['qty']]);
                if ($stockStmt->rowCount() !== 1) {
                    throw new RuntimeException('Sorry, "' . $item['name'] . '" just went out of stock. Please review your cart.');
                }
            }

            $pdo->commit();

            // 4. Clear the cart and prescription now that the order is placed
            unset($_SESSION['cart']);
            unset($_SESSION['prescription_path']);

            redirect('order_success.php?order_id=' . $orderId);

        } catch (RuntimeException $e) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            $error = $e->getMessage();
        } catch (Exception $e) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            $error = "Something went wrong while placing your order. Please try again.";
        }
    }
}

// Show the prescription box only when it is needed
$rxNeeded = $needsPrescription;
$rxReturn = 'checkout';
$canPlaceOrder = !$needsPrescription || $prescriptionPath !== null;

include 'includes/header.php';
?>

<h1><i class="fa-solid fa-lock" aria-hidden="true"></i> Checkout</h1>

<?php if ($flash): ?>
    <div class="alert alert-<?php echo clean($flash['type']); ?>"><?php echo clean($flash['message']); ?></div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error"><?php echo clean($error); ?></div>
<?php endif; ?>
<?php foreach ($cartInfo['notices'] as $notice): ?>
    <div class="alert alert-warning"><?php echo clean($notice); ?></div>
<?php endforeach; ?>

<table>
    <tr><th>Medicine</th><th>Qty</th><th>Subtotal</th></tr>
    <?php foreach ($cart as $item): ?>
        <tr>
            <td><?php echo clean($item['name']); ?></td>
            <td><?php echo (int)$item['qty']; ?></td>
            <td>₹<?php echo number_format($item['subtotal'], 2); ?></td>
        </tr>
    <?php endforeach; ?>
</table>

<h3 class="mt-24">Total: ₹<?php echo number_format($total, 2); ?></h3>

<?php if ($needsPrescription): ?>
    <div class="mt-24">
        <?php include 'includes/rx_upload_box.php'; ?>
    </div>
<?php endif; ?>

<form method="post" class="mt-24">
    <?php echo csrfField(); ?>
    <button type="submit" class="btn" <?php echo $canPlaceOrder ? '' : 'disabled'; ?>>
        <i class="fa-solid fa-bag-shopping" aria-hidden="true"></i> Place Order (Cash on Delivery)
    </button>
    <?php if (!$canPlaceOrder): ?>
        <span class="text-muted">Upload your prescription above to enable this button.</span>
    <?php endif; ?>
</form>

<?php include 'includes/footer.php'; ?>
