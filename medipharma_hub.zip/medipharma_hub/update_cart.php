<?php
// =========================================================
// update_cart.php -- plus / minus / remove for one cart item.
// Works two ways:
//   * with JavaScript (fetch): returns JSON so the cart page updates without a reload
//   * without JavaScript: the same buttons submit normally and the page reloads
// The price always comes from the database, never from the browser.
// =========================================================
require_once 'config/db.php';
require_once 'includes/functions.php';
requireCustomerLogin();

$wantsJson = (($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest');

function cartReply($wantsJson, $ok, $message, $status = 200, $extra = []) {
    if ($wantsJson) {
        http_response_code($status);
        header('Content-Type: application/json');
        echo json_encode(array_merge(['ok' => $ok, 'message' => $message], $extra));
        exit;
    }
    setFlash($ok ? 'success' : 'error', $message);
    redirect('cart.php');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('cart.php');
}
if (!verifyCsrf($_POST['csrf_token'] ?? '')) {
    cartReply($wantsJson, false, 'Your session expired. Please refresh the page and try again.', 403);
}

$id     = (int) ($_POST['medicine_id'] ?? 0);
$action = (string) ($_POST['action'] ?? '');

if (!in_array($action, ['inc', 'dec', 'remove'], true) || !isset($_SESSION['cart'][$id])) {
    cartReply($wantsJson, false, 'That item is not in your cart.', 400);
}

// Check the real stock before accepting a bigger quantity
$stmt = $pdo->prepare("SELECT stock FROM medicines WHERE id = ?");
$stmt->execute([$id]);
$stock = $stmt->fetchColumn();

$message = '';
$ok = true;
$current = (int) $_SESSION['cart'][$id]['qty'];

if ($action === 'remove') {
    unset($_SESSION['cart'][$id]);
    $message = 'Item removed from your cart.';
} elseif ($action === 'inc') {
    if ($stock === false || (int) $stock <= 0) {
        unset($_SESSION['cart'][$id]);
        $ok = false;
        $message = 'This medicine is out of stock and was removed from your cart.';
    } elseif ($current + 1 > (int) $stock) {
        $ok = false;
        $message = 'Only ' . (int) $stock . ' in stock. You cannot add more.';
    } else {
        $_SESSION['cart'][$id]['qty'] = $current + 1;
    }
} else { // dec
    if ($current <= 1) {
        // Quantity can never reach zero: the Remove button is used to delete an item
        $ok = false;
        $message = 'Minimum quantity is 1. Use Remove to delete this item.';
    } else {
        $_SESSION['cart'][$id]['qty'] = $current - 1;
    }
}

// Re-read prices and stock from the database and rebuild the totals
$cart = getCartDetails($pdo);

$extra = [
    'items' => [],
    'total' => number_format($cart['total'], 2),
    'count' => $cart['count'],
    'needs_rx' => $cart['needs_rx'],
    'has_prescription' => validPrescriptionPath() !== null,
    'empty' => empty($cart['items']),
    'notices' => $cart['notices'],
];
foreach ($cart['items'] as $itemId => $item) {
    $extra['items'][$itemId] = [
        'qty' => $item['qty'],
        'subtotal' => number_format($item['subtotal'], 2),
        'can_increase' => $item['qty'] < $item['stock'],
    ];
}

cartReply($wantsJson, $ok, $message, 200, $extra);
