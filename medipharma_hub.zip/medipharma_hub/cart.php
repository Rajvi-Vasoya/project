<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
requireCustomerLogin();

// Prices, stock and the prescription flag always come from the database
$cartInfo          = getCartDetails($pdo);
$cartItems         = $cartInfo['items'];
$total             = $cartInfo['total'];
$needsPrescription = $cartInfo['needs_rx'];
$flash             = takeFlash();

// The prescription box is only shown while the cart holds a prescription-only medicine
$rxNeeded = $needsPrescription;
$rxReturn = 'cart';

include 'includes/header.php';
?>

<h1><i class="fa-solid fa-cart-shopping" aria-hidden="true"></i> Your Cart</h1>

<?php if ($flash): ?>
    <div class="alert alert-<?php echo clean($flash['type']); ?>"><?php echo clean($flash['message']); ?></div>
<?php endif; ?>
<?php foreach ($cartInfo['notices'] as $notice): ?>
    <div class="alert alert-warning"><?php echo clean($notice); ?></div>
<?php endforeach; ?>

<!-- Messages from the plus / minus / remove buttons appear here -->
<div id="cart-message" class="alert" role="status" aria-live="polite" hidden></div>

<p class="text-muted" id="cart-empty" <?php echo empty($cartItems) ? '' : 'hidden'; ?>>Your cart is empty. <a href="medicines.php">Browse medicines</a> to get started.</p>

<div id="cart-content" data-endpoint="update_cart.php" <?php echo empty($cartItems) ? 'hidden' : ''; ?>>

<table>
    <tr>
        <th></th>
        <th>Medicine</th>
        <th>Price</th>
        <th>Quantity</th>
        <th>Subtotal</th>
        <th></th>
    </tr>
    <?php foreach ($cartItems as $id => $item): ?>
        <tr class="cart-row" data-id="<?php echo (int)$id; ?>">
            <td><img src="<?php echo medicineImage($item['image'] ?? null); ?>" alt="" class="thumb"></td>
            <td><?php echo clean($item['name']); ?><?php echo $item['rx'] ? ' <span class="rx-tag">Rx</span>' : ''; ?></td>
            <td>₹<?php echo number_format($item['price'], 2); ?></td>
            <td>
                <form method="post" action="update_cart.php" class="qty-form">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="medicine_id" value="<?php echo (int)$id; ?>">
                    <button type="submit" name="action" value="dec" class="qty-btn qty-minus" data-action="dec"
                            aria-label="Decrease quantity of <?php echo clean($item['name']); ?>" title="Decrease quantity"
                            <?php echo $item['qty'] <= 1 ? 'disabled' : ''; ?>>
                        <i class="fa-solid fa-minus" aria-hidden="true"></i>
                    </button>
                    <span class="qty-value" aria-label="Quantity"><?php echo (int)$item['qty']; ?></span>
                    <button type="submit" name="action" value="inc" class="qty-btn qty-plus" data-action="inc"
                            aria-label="Increase quantity of <?php echo clean($item['name']); ?>" title="Increase quantity"
                            <?php echo $item['qty'] >= $item['stock'] ? 'disabled' : ''; ?>>
                        <i class="fa-solid fa-plus" aria-hidden="true"></i>
                    </button>
                </form>
            </td>
            <td>₹<span class="row-subtotal"><?php echo number_format($item['subtotal'], 2); ?></span></td>
            <td>
                <form method="post" action="update_cart.php" class="remove-form">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="medicine_id" value="<?php echo (int)$id; ?>">
                    <button type="submit" name="action" value="remove" class="link-btn remove-btn" data-action="remove"
                            aria-label="Remove <?php echo clean($item['name']); ?> from cart" title="Remove from cart">
                        <i class="fa-solid fa-trash-can" aria-hidden="true"></i> Remove
                    </button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<div class="flex-between mt-24">
    <h3>Total: ₹<span id="cart-total"><?php echo number_format($total, 2); ?></span></h3>
    <a href="checkout.php" class="btn"><i class="fa-solid fa-lock" aria-hidden="true"></i> Proceed to Checkout</a>
</div>

<div class="mt-24">
    <?php include 'includes/rx_upload_box.php'; ?>
</div>

</div>

<script src="assets/js/cart.js"></script>

<?php include 'includes/footer.php'; ?>
