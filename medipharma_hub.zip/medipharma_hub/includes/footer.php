</main>
<footer class="site-footer">
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> MediPharma Hub &mdash; Online Pharmacy & Medicine Order Portal.</p>
    </div>
</footer>
</body>
</html>
