<?php
// =========================================================
// Small reusable helper functions used across the site
// =========================================================

// Clean up any text coming from a form before using/displaying it
function clean($value) {
    return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
}

// Stop the page and send the visitor somewhere else
function redirect($path) {
    header("Location: $path");
    exit;
}

// Only allow logged-in customers to view a page
function requireCustomerLogin() {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'customer') {
        redirect('login.php');
    }
}

// Only allow the admin to view a page (used inside /admin/*.php)
function requireAdminLogin() {
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
        redirect('../login.php');   // '../' because admin pages live inside /admin
    }
}

// Returns the list of medicines whose stock has fallen below their
// own minimum threshold -- this powers the low-stock admin alert.
function getLowStockMedicines($pdo) {
    $sql = "SELECT * FROM medicines WHERE stock <= min_threshold ORDER BY stock ASC";
    return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
}

// ---------------------------------------------------------
// Medicine photo helpers
// ---------------------------------------------------------
define('MEDICINE_IMG_DIR', __DIR__ . '/../assets/uploads/medicines/');

// URL for a medicine photo. $prefix is '' on normal pages and '../' inside /admin.
// Falls back to a placeholder when the medicine has no photo (or the file is missing).
function medicineImage($image, $prefix = '') {
    if (!empty($image) && file_exists(MEDICINE_IMG_DIR . basename($image))) {
        return $prefix . 'assets/uploads/medicines/' . rawurlencode(basename($image));
    }
    return $prefix . 'assets/images/no-image.png';
}

// Validates and stores an uploaded medicine photo.
// Returns [filename or null, error message or '']. No file chosen => [null, ''].
function saveMedicineImage($file, $medicineName) {
    if (!isset($file) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return [null, ''];
    }
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return [null, 'Photo upload failed. Please try again.'];
    }
    if ($file['size'] > 2 * 1024 * 1024) {
        return [null, 'Photo is too large (max 2MB).'];
    }
    // Check the real image type, not just the file extension
    $info = @getimagesize($file['tmp_name']);
    $types = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    if (!$info || !isset($types[$info[2]])) {
        return [null, 'Only JPG, PNG or WEBP photos are allowed.'];
    }
    if (!is_dir(MEDICINE_IMG_DIR)) {
        mkdir(MEDICINE_IMG_DIR, 0755, true);
    }
    $slug = trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($medicineName)), '-');
    $newName = ($slug !== '' ? $slug : 'medicine') . '-' . time() . '.' . $types[$info[2]];
    if (!move_uploaded_file($file['tmp_name'], MEDICINE_IMG_DIR . $newName)) {
        return [null, 'Could not save the photo.'];
    }
    return [$newName, ''];
}

// Removes a stored medicine photo from disk (safe if the file doesn't exist)
function deleteMedicineImage($image) {
    if (!empty($image)) {
        $path = MEDICINE_IMG_DIR . basename($image);
        if (is_file($path)) {
            @unlink($path);
        }
    }
}

// ---------------------------------------------------------
// Security helpers: CSRF protection and one-time (flash) messages
// ---------------------------------------------------------

// Returns this session's CSRF token (created the first time it is needed)
function csrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Hidden input to place inside every state-changing <form method="post">
function csrfField() {
    return '<input type="hidden" name="csrf_token" value="' . csrfToken() . '">';
}

// True only when the submitted token matches the one stored in the session
function verifyCsrf($token) {
    return is_string($token)
        && !empty($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

// One-time message shown on the next page ($type: 'success', 'error' or 'warning')
function setFlash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}
function takeFlash() {
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $flash;
}

// ---------------------------------------------------------
// Cart helpers (the cart still lives in $_SESSION['cart'])
// ---------------------------------------------------------

// Rebuilds the cart from the REAL database values (price, stock, prescription flag),
// so a tampered session/browser request can never change a price.
// Quantities are limited to the available stock; medicines that were deleted or are
// out of stock are dropped. The session cart is refreshed and a list of notices is returned.
// Returns ['items' => [...], 'total' => float, 'count' => int, 'needs_rx' => bool, 'notices' => [...]]
function getCartDetails($pdo) {
    $cart = $_SESSION['cart'] ?? [];
    $result = ['items' => [], 'total' => 0.0, 'count' => 0, 'needs_rx' => false, 'notices' => []];
    if (empty($cart) || !is_array($cart)) {
        $_SESSION['cart'] = [];
        return $result;
    }

    $ids = array_map('intval', array_keys($cart));
    $in  = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("SELECT id, name, price, stock, requires_prescription, image FROM medicines WHERE id IN ($in)");
    $stmt->execute($ids);
    $rows = [];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $rows[(int)$row['id']] = $row;
    }

    $newCart = [];
    foreach ($cart as $id => $line) {
        $id  = (int)$id;
        $qty = max(1, (int)($line['qty'] ?? 1));
        if (!isset($rows[$id])) {
            $result['notices'][] = ($line['name'] ?? 'An item') . ' is no longer available and was removed from your cart.';
            continue;
        }
        $m = $rows[$id];
        $stock = (int)$m['stock'];
        if ($stock <= 0) {
            $result['notices'][] = $m['name'] . ' is out of stock and was removed from your cart.';
            continue;
        }
        if ($qty > $stock) {
            $qty = $stock;
            $result['notices'][] = 'Only ' . $stock . ' of ' . $m['name'] . ' are in stock, so the quantity was adjusted.';
        }
        $price = (float)$m['price'];
        $rx    = (int)$m['requires_prescription'] === 1;

        $newCart[$id] = [
            'name'  => $m['name'],
            'price' => $m['price'],
            'qty'   => $qty,
            'requires_prescription' => $m['requires_prescription'],
            'image' => $m['image'],
        ];
        $result['items'][$id] = [
            'id' => $id, 'name' => $m['name'], 'price' => $price, 'qty' => $qty,
            'stock' => $stock, 'rx' => $rx, 'image' => $m['image'],
            'subtotal' => round($price * $qty, 2),
        ];
        $result['total'] += $price * $qty;
        $result['count'] += $qty;
        if ($rx) { $result['needs_rx'] = true; }
    }
    $result['total'] = round($result['total'], 2);
    $_SESSION['cart'] = $newCart;
    return $result;
}

// Returns the stored prescription path only if it really belongs to this customer
// and the file still exists. Otherwise returns null.
function validPrescriptionPath() {
    $path = $_SESSION['prescription_path'] ?? '';
    if (!is_string($path) || $path === '' || !isset($_SESSION['user_id'])) {
        return null;
    }
    $prefix = 'assets/uploads/rx_' . (int)$_SESSION['user_id'] . '_';
    if (strpos($path, $prefix) !== 0 || basename($path) !== substr($path, strlen('assets/uploads/'))) {
        return null;
    }
    return is_file(__DIR__ . '/../' . $path) ? $path : null;
}

// ---------------------------------------------------------
// Order helpers
// ---------------------------------------------------------

// Statuses (from the orders.status column) in which a customer may still cancel.
// Once an order is 'shipped' or 'delivered' (or already 'cancelled') it can no longer be cancelled.
function cancellableOrderStatuses() {
    return ['pending', 'processing'];
}
function isOrderCancellable($status) {
    return in_array($status, cancellableOrderStatuses(), true);
}
