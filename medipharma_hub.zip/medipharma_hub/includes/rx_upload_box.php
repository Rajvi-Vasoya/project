<?php
// =========================================================
// Prescription upload box, shared by cart.php and checkout.php.
// Expects:  $rxNeeded (bool)  - does the cart contain a prescription-only medicine?
//           $rxReturn (string) - 'cart' or 'checkout' (where to come back after uploading)
// When no prescription is needed the box stays hidden AND disabled, so the file
// field cannot be seen, filled in or submitted.
// =========================================================
$rxCurrent = validPrescriptionPath();
?>
<section class="card rx-box" id="rx-section" <?php echo $rxNeeded ? '' : 'hidden'; ?>>
    <fieldset id="rx-fieldset" <?php echo $rxNeeded ? '' : 'disabled'; ?>>
        <h3><i class="fa-solid fa-file-prescription" aria-hidden="true"></i> Prescription required</h3>
        <p class="text-muted">One or more medicines in your cart need a valid prescription. Upload a clear photo or PDF of it to place your order.</p>

        <?php if ($rxCurrent): ?>
            <div class="alert alert-success" id="rx-status">
                <i class="fa-solid fa-circle-check" aria-hidden="true"></i>
                Prescription attached: <?php echo clean(basename($rxCurrent)); ?>
            </div>
        <?php else: ?>
            <div class="alert alert-warning" id="rx-status">
                <i class="fa-solid fa-circle-exclamation" aria-hidden="true"></i>
                No prescription uploaded yet. It is required before you can place the order.
            </div>
        <?php endif; ?>

        <form method="post" action="upload_prescription.php" enctype="multipart/form-data" id="rx-form">
            <?php echo csrfField(); ?>
            <input type="hidden" name="return" value="<?php echo clean($rxReturn); ?>">
            <label for="rx-file"><?php echo $rxCurrent ? 'Replace prescription (JPG, PNG or PDF, max 5MB)' : 'Choose file (JPG, PNG or PDF, max 5MB)'; ?></label>
            <input type="file" id="rx-file" name="prescription" accept=".jpg,.jpeg,.png,.pdf" required>
            <button type="submit" class="btn btn-secondary btn-small mt-24"><i class="fa-solid fa-upload" aria-hidden="true"></i> Upload Prescription</button>
        </form>
    </fieldset>
</section>
