<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php $basePath = (strpos($_SERVER['PHP_SELF'], '/admin/') !== false) ? '../' : ''; ?>
<title>MediPharma Hub</title>
<link rel="icon" type="image/png" href="<?php echo $basePath; ?>assets/images/logo.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="<?php echo $basePath; ?>assets/css/style.css">
</head>
<body>
<header class="site-header">
    <div class="container header-inner">
        <a href="<?php echo $basePath; ?>index.php" class="logo">
            <img src="<?php echo $basePath; ?>assets/images/logo5.png" alt="MediPharma Hub logo">
        </a>
        <nav class="main-nav">
            <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'admin'): ?>
                <a href="<?php echo $basePath === '' ? 'admin/dashboard.php' : 'dashboard.php'; ?>"><i class="fa-solid fa-gauge-high" aria-hidden="true"></i> Admin Dashboard</a>
                <a href="<?php echo $basePath === '' ? 'admin/logout.php' : 'logout.php'; ?>"><i class="fa-solid fa-right-from-bracket" aria-hidden="true"></i> Logout</a>
            <?php elseif (isset($_SESSION['user_id'])): ?>
                <?php
                // Cart size for the header badge, and whether any cart item needs a prescription
                $hdrCartQty = 0;
                $hdrNeedsRx = false;
                foreach (($_SESSION['cart'] ?? []) as $hdrLine) {
                    $hdrCartQty += (int) ($hdrLine['qty'] ?? 0);
                    if (!empty($hdrLine['requires_prescription'])) { $hdrNeedsRx = true; }
                }
                ?>
                <a href="<?php echo $basePath; ?>medicines.php"><i class="fa-solid fa-pills" aria-hidden="true"></i> Shop Medicines</a>
                <a href="<?php echo $basePath; ?>cart.php"><i class="fa-solid fa-cart-shopping" aria-hidden="true"></i> Cart<span id="cart-count"><?php if ($hdrCartQty > 0) echo ' (' . $hdrCartQty . ')'; ?></span></a>
                <?php if ($hdrNeedsRx): ?>
                    <a href="<?php echo $basePath; ?>upload_prescription.php"><i class="fa-solid fa-file-prescription" aria-hidden="true"></i> Upload Prescription</a>
                <?php endif; ?>
                <a href="<?php echo $basePath; ?>my_orders.php"><i class="fa-solid fa-box-open" aria-hidden="true"></i> My Orders</a>
                <a href="<?php echo $basePath; ?>profile.php"><i class="fa-solid fa-user" aria-hidden="true"></i> My Profile</a>
                <a href="<?php echo $basePath; ?>logout.php"><i class="fa-solid fa-right-from-bracket" aria-hidden="true"></i> Logout (<?php echo htmlspecialchars($_SESSION['name']); ?>)</a>
            <?php else: ?>
                <a href="<?php echo $basePath; ?>index.php"><i class="fa-solid fa-house" aria-hidden="true"></i> Home</a>
                <a href="<?php echo $basePath; ?>medicines.php"><i class="fa-solid fa-pills" aria-hidden="true"></i> Medicines</a>
                <a href="<?php echo $basePath; ?>login.php"><i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i> Login</a>
                <a href="<?php echo $basePath; ?>register.php"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> Register</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main class="container page-body">
