<?php
// =========================================================
// Database connection settings
// =========================================================
$DB_HOST = "localhost"; // Do not include :8080 here!
$DB_NAME = "medipharma_hub";
$DB_USER = "root";
$DB_PASS = "";
$port    = '3307'; // This is correct for your MySQL

try {
    // The DSN uses the host and the port separately
    $dsn = "mysql:host=$DB_HOST;port=$port;dbname=$DB_NAME;charset=utf8mb4";
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS);
    
    // Show real errors as exceptions instead of silent failures
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Start session on every page that includes this file
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>