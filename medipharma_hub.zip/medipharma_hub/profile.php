<?php
// =========================================================
// profile.php -- a logged-in customer views and edits THEIR OWN profile.
// The user id always comes from the login session, never from the request,
// so one customer cannot open or change another customer's account.
// Uses the existing `users` columns only: full_name, email, phone, address.
// =========================================================
require_once 'config/db.php';
require_once 'includes/functions.php';
requireCustomerLogin();

$userId = (int) $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT id, full_name, email, phone, address, created_at FROM users WHERE id = ? AND role = 'customer'");
$stmt->execute([$userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) {
    redirect('logout.php');
}

// Values saved by register.php are stored HTML-escaped (via clean()). To show them
// correctly they are decoded once and escaped again when printed.
function profileShow($value) {
    return clean(html_entity_decode((string) $value, ENT_QUOTES, 'UTF-8'));
}

$errors = [];     // field name => message
$form   = [       // what is shown inside the edit form
    'full_name' => html_entity_decode((string) $user['full_name'], ENT_QUOTES, 'UTF-8'),
    'email'     => html_entity_decode((string) $user['email'], ENT_QUOTES, 'UTF-8'),
    'phone'     => html_entity_decode((string) ($user['phone'] ?? ''), ENT_QUOTES, 'UTF-8'),
    'address'   => html_entity_decode((string) ($user['address'] ?? ''), ENT_QUOTES, 'UTF-8'),
];
$editOpen = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $editOpen = true;

    if (!verifyCsrf($_POST['csrf_token'] ?? '')) {
        $errors['form'] = 'Your session expired. Please try again.';
    } else {
        foreach (['full_name', 'email', 'phone', 'address'] as $field) {
            $form[$field] = isset($_POST[$field]) && is_string($_POST[$field]) ? trim($_POST[$field]) : '';
        }

        // ---- Validation (the same rules are checked in profile.js for convenience) ----
        $nameLen = mb_strlen($form['full_name']);
        if ($nameLen < 2 || $nameLen > 100) {
            $errors['full_name'] = 'Please enter your full name (2 to 100 characters).';
        }

        if ($form['email'] === '' || !filter_var($form['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($form['email']) > 150) {
            $errors['email'] = 'Please enter a valid email address.';
        }

        $phoneDigits = preg_replace('/\D/', '', $form['phone']);
        if (!preg_match('/^\+?[0-9][0-9\s\-()]*$/', $form['phone']) || strlen($phoneDigits) < 7 || strlen($phoneDigits) > 15 || strlen($form['phone']) > 20) {
            $errors['phone'] = 'Please enter a valid phone number (7 to 15 digits; you may use + - ( ) and spaces).';
        }

        $addrLen = mb_strlen($form['address']);
        if ($addrLen < 5 || $addrLen > 255) {
            $errors['address'] = 'Please enter your delivery address (5 to 255 characters).';
        }

        // Same storage format as register.php, and it must still fit the column sizes
        $store = [
            'full_name' => clean($form['full_name']),
            'email'     => clean($form['email']),
            'phone'     => clean($form['phone']),
            'address'   => clean($form['address']),
        ];
        $limits = ['full_name' => 100, 'email' => 150, 'phone' => 20, 'address' => 255];
        foreach ($limits as $field => $max) {
            if (!isset($errors[$field]) && mb_strlen($store[$field]) > $max) {
                $errors[$field] = 'This value is too long.';
            }
        }

        // The email must not belong to a different account
        if (!isset($errors['email'])) {
            $dup = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id <> ?");
            $dup->execute([$store['email'], $userId]);
            if ($dup->fetch()) {
                $errors['email'] = 'This email address is already used by another account.';
            }
        }

        if (!$errors) {
            try {
                // WHERE id = logged-in user: nobody else's row can be touched
                $upd = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, address = ? WHERE id = ? AND role = 'customer'");
                $upd->execute([$store['full_name'], $store['email'], $store['phone'], $store['address'], $userId]);

                $_SESSION['name'] = $store['full_name'];   // keeps the header name up to date
                setFlash('success', 'Your profile has been updated successfully.');
                redirect('profile.php');
            } catch (PDOException $e) {
                if ($e->getCode() === '23000') {
                    $errors['email'] = 'This email address is already used by another account.';
                } else {
                    $errors['form'] = 'Something went wrong while saving your profile. Please try again.';
                }
            }
        }
    }
}

$flash = takeFlash();

include 'includes/header.php';
?>

<h1><i class="fa-solid fa-user" aria-hidden="true"></i> My Profile</h1>

<div class="profile-wrap">

    <?php if ($flash): ?>
        <div class="alert alert-<?php echo clean($flash['type']); ?>" role="status">
            <i class="fa-solid fa-circle-check" aria-hidden="true"></i> <?php echo clean($flash['message']); ?>
        </div>
    <?php endif; ?>
    <?php if ($errors): ?>
        <div class="alert alert-error" role="alert">
            <i class="fa-solid fa-circle-exclamation" aria-hidden="true"></i>
            <?php echo isset($errors['form']) ? clean($errors['form']) : 'Please fix the highlighted fields and try again.'; ?>
        </div>
    <?php endif; ?>

    <!-- ============ View mode ============ -->
    <div class="card profile-card" id="profile-view" <?php echo $editOpen ? 'hidden' : ''; ?>>
        <dl class="profile-list">
            <div><dt><i class="fa-solid fa-user" aria-hidden="true"></i> Full name</dt><dd><?php echo profileShow($user['full_name']); ?></dd></div>
            <div><dt><i class="fa-solid fa-envelope" aria-hidden="true"></i> Email</dt><dd><?php echo profileShow($user['email']); ?></dd></div>
            <div><dt><i class="fa-solid fa-phone" aria-hidden="true"></i> Phone</dt><dd><?php echo $user['phone'] !== null && $user['phone'] !== '' ? profileShow($user['phone']) : '<span class="text-muted">Not added</span>'; ?></dd></div>
            <div><dt><i class="fa-solid fa-location-dot" aria-hidden="true"></i> Delivery address</dt><dd><?php echo $user['address'] !== null && $user['address'] !== '' ? nl2br(profileShow($user['address'])) : '<span class="text-muted">Not added</span>'; ?></dd></div>
            <div><dt><i class="fa-solid fa-calendar-check" aria-hidden="true"></i> Member since</dt><dd><?php echo date('d M Y', strtotime($user['created_at'])); ?></dd></div>
        </dl>
        <button type="button" class="btn" id="profile-edit-btn" aria-controls="profile-edit" aria-expanded="false">
            <i class="fa-solid fa-pen-to-square" aria-hidden="true"></i> Edit Profile
        </button>
    </div>

    <!-- ============ Edit mode ============ -->
    <div class="card profile-card" id="profile-edit" <?php echo $editOpen ? '' : 'hidden'; ?>>
        <noscript><style>#profile-edit[hidden] { display: block; }</style></noscript>
        <form method="post" action="profile.php" id="profile-form" novalidate>
            <?php echo csrfField(); ?>

            <label for="full_name">Full name *</label>
            <input type="text" id="full_name" name="full_name" maxlength="100" required
                   value="<?php echo clean($form['full_name']); ?>" <?php echo isset($errors['full_name']) ? 'aria-invalid="true"' : ''; ?>>
            <p class="field-error" data-error-for="full_name" <?php echo isset($errors['full_name']) ? '' : 'hidden'; ?>><?php echo isset($errors['full_name']) ? clean($errors['full_name']) : ''; ?></p>

            <label for="email">Email *</label>
            <input type="email" id="email" name="email" maxlength="150" required
                   value="<?php echo clean($form['email']); ?>" <?php echo isset($errors['email']) ? 'aria-invalid="true"' : ''; ?>>
            <p class="field-error" data-error-for="email" <?php echo isset($errors['email']) ? '' : 'hidden'; ?>><?php echo isset($errors['email']) ? clean($errors['email']) : ''; ?></p>

            <label for="phone">Phone *</label>
            <input type="text" id="phone" name="phone" maxlength="20" required inputmode="tel"
                   value="<?php echo clean($form['phone']); ?>" <?php echo isset($errors['phone']) ? 'aria-invalid="true"' : ''; ?>>
            <p class="field-error" data-error-for="phone" <?php echo isset($errors['phone']) ? '' : 'hidden'; ?>><?php echo isset($errors['phone']) ? clean($errors['phone']) : ''; ?></p>

            <label for="address">Delivery address *</label>
            <textarea id="address" name="address" rows="3" maxlength="255" required <?php echo isset($errors['address']) ? 'aria-invalid="true"' : ''; ?>><?php echo clean($form['address']); ?></textarea>
            <p class="field-error" data-error-for="address" <?php echo isset($errors['address']) ? '' : 'hidden'; ?>><?php echo isset($errors['address']) ? clean($errors['address']) : ''; ?></p>

            <div class="profile-actions">
                <button type="submit" class="btn"><i class="fa-solid fa-floppy-disk" aria-hidden="true"></i> Save Changes</button>
                <button type="button" class="btn btn-secondary" id="profile-cancel-btn"><i class="fa-solid fa-xmark" aria-hidden="true"></i> Cancel</button>
            </div>
        </form>
    </div>
</div>

<script src="assets/js/profile.js"></script>

<?php include 'includes/footer.php'; ?>
