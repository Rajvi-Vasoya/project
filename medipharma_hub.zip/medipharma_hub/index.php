<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// Real numbers pulled from the database for the stats section
$categoryCount = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$medicineCount = $pdo->query("SELECT COUNT(*) FROM medicines")->fetchColumn();
$customerCount = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
$orderCount    = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();

// Simple icon map so each category card gets a relevant icon
$categoryIcons = [
    'Nutritional Supplements'          => 'fa-capsules',
    'Ayurvedic Products'               => 'fa-leaf',
    'Diabetes Care'                    => 'fa-droplet',
    'Personal Care'                    => 'fa-pump-soap',
    'Eye, Ear, Nose & Dental Care'     => 'fa-eye',
    'Cough & Cold'                     => 'fa-head-side-cough',
    'Health Care Devices'              => 'fa-heart-pulse',
    'Generic Medicines'                => 'fa-pills',
    'Heart Care'                       => 'fa-heart',
    'Blood Pressure'                   => 'fa-gauge-high',
    'Kidney Care'                      => 'fa-droplet',
    'Elderly Care'                     => 'fa-person-cane',
];

include 'includes/header.php';
?>

<section class="hero" id="top">
    <h1>Your medicines, delivered with care.</h1>
    <p>Search by category, upload your prescription, and place your order in minutes &mdash; MediPharma Hub keeps your essentials always in stock.</p>
    <a href="medicines.php" class="btn">Browse Medicines</a>
    <?php if (!isset($_SESSION['user_id'])): ?>
        <a href="register.php" class="btn btn-outline" style="margin-left:10px;">Create Account</a>
    <?php endif; ?>

    <div class="hero-jumplinks">
        <a href="#about">About</a>
        <a href="#categories">Categories</a>
        <a href="#why-us">Why Choose Us</a>
        <a href="#contact">Contact</a>
    </div>
</section>

<!-- ================= ABOUT ================= -->
<section id="about" class="section">
    <div class="about-grid">
        <div>
            <span class="section-eyebrow">About Us</span>
            <h2>A pharmacy portal built around trust and availability</h2>
            <p class="text-muted">
                MediPharma Hub connects you to the medicines you need, organized clearly by category and backed by
                an admin team that keeps a constant eye on stock levels. Prescription-only medicines are clearly
                flagged, so you always know what needs a doctor's approval before checkout.
            </p>
            <p class="text-muted">
                Behind the scenes, our system automatically flags any medicine that falls below its safe stock
                threshold &mdash; so shortages get caught and restocked before they ever reach you.
            </p>
        </div>
        <div class="about-icon-panel">
            <i class="fa-solid fa-house-medical"></i>
        </div>
    </div>
</section>

<!-- ================= STATS ================= -->
<section class="section stats-section">
    <div class="stats-grid">
        <div class="stat-card">
            <i class="fa-solid fa-layer-group"></i>
            <h3><?php echo $categoryCount; ?></h3>
            <p>Medicine Categories</p>
        </div>
        <div class="stat-card">
            <i class="fa-solid fa-prescription-bottle-medical"></i>
            <h3><?php echo $medicineCount; ?></h3>
            <p>Medicines Available</p>
        </div>
        <div class="stat-card">
            <i class="fa-solid fa-user-group"></i>
            <h3><?php echo $customerCount; ?></h3>
            <p>Registered Customers</p>
        </div>
        <div class="stat-card">
            <i class="fa-solid fa-truck-medical"></i>
            <h3><?php echo $orderCount; ?></h3>
            <p>Orders Placed</p>
        </div>
    </div>
</section>

<!-- ================= CATEGORIES ================= -->
<section id="categories" class="section">
    <span class="section-eyebrow">Shop by Category</span>
    <h2>Find exactly what you need, faster</h2>
    <div class="grid cat-icon-grid mt-24">
        <?php foreach ($categories as $cat):
            $icon = $categoryIcons[$cat['name']] ?? 'fa-briefcase-medical';
        ?>
            <a href="medicines.php?category=<?php echo $cat['id']; ?>" class="cat-icon-card">
                <i class="fa-solid <?php echo $icon; ?>"></i>
                <h3><?php echo clean($cat['name']); ?></h3>
                <span class="text-muted">View medicines &rarr;</span>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<!-- ================= WHY CHOOSE US ================= -->
<section id="why-us" class="section why-us-section">
    <span class="section-eyebrow">Why Choose Us</span>
    <h2>What makes MediPharma Hub reliable</h2>
    <div class="advantages-grid mt-24">
        <div class="advantage-item"><i class="fa-solid fa-check"></i> Wide range of medicines across various categories</div>
        <div class="advantage-item"><i class="fa-solid fa-check"></i> Clear labeling of prescription-only medicines</div>
        <div class="advantage-item"><i class="fa-solid fa-check"></i> Prescription upload before checkout</div>
        <div class="advantage-item"><i class="fa-solid fa-check"></i> Real-time low-stock monitoring by our admin team</div>
        <div class="advantage-item"><i class="fa-solid fa-check"></i> Customer can simply place orders</div>
        <div class="advantage-item"><i class="fa-solid fa-check"></i> Straightforward account registration and login</div>
    </div>
</section>

<!-- ================= CONTACT ================= -->
<section id="contact" class="section contact-section">
    <div class="contact-box">
        <div>
            <span class="section-eyebrow">Get in Touch</span>
            <h2>Questions about an order or a medicine?</h2>
        </div>
        <div class="contact-details">
            <p><i class="fa-solid fa-envelope"></i> support@medipharmahub.com</p>
            <p><i class="fa-solid fa-phone"></i> +91 75394 51628</p>
            <p><i class="fa-solid fa-location-dot"></i> MediPharma Hub, Jamnagar, India</p>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
