<?php
// =========================================================
// medicines.php  --  Medicine shopping page
// Search + category + price range + availability filters,
// sorting and pagination. Everything is read from the real
// `medicines` and `categories` tables (PDO prepared statements).
// =========================================================
require_once 'config/db.php';
require_once 'includes/functions.php';

// ---- Settings you can change ----
$perPage = 12;   // medicines shown on one page

// ---------------------------------------------------------
// Small helpers (only used on this page)
// ---------------------------------------------------------

// Read a GET value as a plain string (ignores arrays like ?q[]=x)
function getString($key) {
    return (isset($_GET[$key]) && is_string($_GET[$key])) ? trim($_GET[$key]) : '';
}

// 100.00 -> "100", 99.5 -> "99.5"  (neat numbers for URLs and labels)
function fmtNum($n) {
    return rtrim(rtrim(number_format((float)$n, 2, '.', ''), '0'), '.');
}

// Builds a medicines.php URL from the current filters.
// $override changes some values (use null to remove one), e.g. ['page' => 2].
function shopUrl(array $state, array $override = []) {
    $s  = array_merge($state, $override);
    $qs = [];
    foreach (['q', 'category', 'min_price', 'max_price', 'sort', 'instock', 'page'] as $key) {
        if (isset($s[$key]) && $s[$key] !== '' && $s[$key] !== null) {
            $qs[$key] = $s[$key];
        }
    }
    if (isset($qs['sort']) && $qs['sort'] === 'name_asc') { unset($qs['sort']); }   // default sort
    if (isset($qs['page']) && (int)$qs['page'] <= 1)      { unset($qs['page']); }   // page 1 is default
    $str = http_build_query($qs);
    return 'medicines.php' . ($str !== '' ? '?' . $str : '');
}

// ---------------------------------------------------------
// 1. Categories and overall price range (from the database)
// ---------------------------------------------------------
$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// How many medicines each category has (shown next to the category name)
$categoryCounts = [];
$totalMedicines = 0;
foreach ($pdo->query("SELECT category_id, COUNT(*) AS total FROM medicines GROUP BY category_id") as $row) {
    if ($row['category_id'] !== null) {
        $categoryCounts[(int)$row['category_id']] = (int)$row['total'];
    }
    $totalMedicines += (int)$row['total'];
}

// Lowest and highest price in the store: these are the slider limits
$range       = $pdo->query("SELECT MIN(price) AS lo, MAX(price) AS hi FROM medicines")->fetch(PDO::FETCH_ASSOC);
$boundsMin   = (int) floor((float)$range['lo']);
$boundsMax   = (int) ceil((float)$range['hi']);
if ($boundsMax <= $boundsMin) { $boundsMax = $boundsMin + 1; }   // avoids a zero-width slider

// ---------------------------------------------------------
// 2. Read and validate what the visitor selected
// ---------------------------------------------------------
$q = mb_substr(getString('q'), 0, 100);

// Category: must be a real category id
$categoryId   = (int) getString('category');
$categoryName = '';
foreach ($categories as $cat) {
    if ((int)$cat['id'] === $categoryId) { $categoryName = $cat['name']; }
}
if ($categoryName === '') { $categoryId = 0; }

// Prices: must be numbers, zero or more
$minPrice = null;
$maxPrice = null;
$rawMin = getString('min_price');
$rawMax = getString('max_price');
if ($rawMin !== '' && is_numeric($rawMin) && (float)$rawMin >= 0) { $minPrice = min((float)$rawMin, 9999999); }
if ($rawMax !== '' && is_numeric($rawMax) && (float)$rawMax >= 0) { $maxPrice = min((float)$rawMax, 9999999); }
if ($minPrice !== null && $maxPrice !== null && $minPrice > $maxPrice) {   // user typed them the wrong way round
    list($minPrice, $maxPrice) = [$maxPrice, $minPrice];
}
// A value equal to the store's own limit is not really a filter
$activeMin = ($minPrice !== null && $minPrice > $boundsMin) ? $minPrice : null;
$activeMax = ($maxPrice !== null && $maxPrice < $boundsMax) ? $maxPrice : null;

// In-stock only
$inStock = (getString('instock') === '1');

// Sorting: only these four options are allowed (so nothing unsafe reaches the SQL)
$sortOptions = [
    'name_asc'   => ['Name: A to Z',        'm.name ASC'],
    'name_desc'  => ['Name: Z to A',        'm.name DESC'],
    'price_asc'  => ['Price: Low to High',  'm.price ASC, m.name ASC'],
    'price_desc' => ['Price: High to Low',  'm.price DESC, m.name ASC'],
];
$sort = getString('sort');
if (!isset($sortOptions[$sort])) { $sort = 'name_asc'; }

// The current filters, packed together so links can keep them
$state = [
    'q'         => $q,
    'category'  => $categoryId > 0 ? $categoryId : null,
    'min_price' => $activeMin !== null ? fmtNum($activeMin) : null,
    'max_price' => $activeMax !== null ? fmtNum($activeMax) : null,
    'sort'      => $sort,
    'instock'   => $inStock ? 1 : null,
];

// ---------------------------------------------------------
// 3. Build the SQL (values go in as ? parameters)
// ---------------------------------------------------------
$where  = [];
$params = [];

if ($q !== '') {
    $where[]  = "m.name LIKE ?";
    // escape % and _ so they are searched as normal characters
    $params[] = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
}
if ($categoryId > 0) {
    $where[]  = "m.category_id = ?";
    $params[] = $categoryId;
}
if ($activeMin !== null) {
    $where[]  = "m.price >= ?";
    $params[] = $activeMin;
}
if ($activeMax !== null) {
    $where[]  = "m.price <= ?";
    $params[] = $activeMax;
}
if ($inStock) {
    $where[] = "m.stock > 0";
}
$whereSql = $where ? " WHERE " . implode(" AND ", $where) : "";

// How many medicines match? (needed for the result count and pagination)
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM medicines m" . $whereSql);
$countStmt->execute($params);
$totalResults = (int) $countStmt->fetchColumn();

$totalPages = max(1, (int) ceil($totalResults / $perPage));
$page       = (int) getString('page');
if ($page < 1)           { $page = 1; }
if ($page > $totalPages) { $page = $totalPages; }
$offset = ($page - 1) * $perPage;

// Fetch only the medicines for this page
$sql = "SELECT m.*, c.name AS category_name
        FROM medicines m
        LEFT JOIN categories c ON c.id = m.category_id"
     . $whereSql
     . " ORDER BY " . $sortOptions[$sort][1] . ", m.id ASC"
     . " LIMIT " . (int)$perPage . " OFFSET " . (int)$offset;   // both are whole numbers, so this is safe
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$medicines = $stmt->fetchAll(PDO::FETCH_ASSOC);

// ---------------------------------------------------------
// 4. Things the page needs for display
// ---------------------------------------------------------
// Active filter "chips" (each one has a link that removes just that filter)
$chips = [];
if ($q !== '') {
    $chips[] = ['Search: &ldquo;' . clean($q) . '&rdquo;', shopUrl($state, ['q' => null])];
}
if ($categoryId > 0) {
    $chips[] = [clean($categoryName), shopUrl($state, ['category' => null])];
}
if ($activeMin !== null || $activeMax !== null) {
    if ($activeMin !== null && $activeMax !== null) {
        $label = '₹' . fmtNum($activeMin) . ' &ndash; ₹' . fmtNum($activeMax);
    } elseif ($activeMin !== null) {
        $label = 'From ₹' . fmtNum($activeMin);
    } else {
        $label = 'Up to ₹' . fmtNum($activeMax);
    }
    $chips[] = [$label, shopUrl($state, ['min_price' => null, 'max_price' => null])];
}
if ($inStock) {
    $chips[] = ['In stock only', shopUrl($state, ['instock' => null])];
}
if ($sort !== 'name_asc') {
    $chips[] = [clean($sortOptions[$sort][0]), shopUrl($state, ['sort' => null])];
}
$filterCount = count($chips) - ($sort !== 'name_asc' ? 1 : 0);   // sorting is not counted as a filter

// Remember where the visitor was, so Add to Cart can bring them back here
$returnQs = (string) parse_url(shopUrl($state, ['page' => $page]), PHP_URL_QUERY);

// Values shown in the price boxes and slider
$minShown = $minPrice !== null ? fmtNum($minPrice) : (string)$boundsMin;
$maxShown = $maxPrice !== null ? fmtNum($maxPrice) : (string)$boundsMax;

include 'includes/header.php';
?>

<div class="shop-head">
    <h1>Browse Medicines</h1>
    <p class="text-muted">Search our range, narrow it down with filters and add what you need to your cart.</p>
</div>

<!-- Every search/filter input below points to this form with form="shop-filters" -->
<form method="get" action="medicines.php" id="shop-filters"></form>

<!-- ============ Search + sort bar ============ -->
<div class="shop-toolbar">
    <div class="search-box">
        <i class="fa-solid fa-magnifying-glass"></i>
        <input type="text" name="q" form="shop-filters" maxlength="100"
               placeholder="Search medicine by name..." value="<?php echo clean($q); ?>">
    </div>
    <button type="submit" form="shop-filters" class="btn btn-secondary"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i> Search</button>

    <div class="sort-box">
        <label for="sort">Sort by</label>
        <select name="sort" id="sort" form="shop-filters" data-autosubmit>
            <?php foreach ($sortOptions as $value => $opt): ?>
                <option value="<?php echo $value; ?>" <?php echo $sort === $value ? 'selected' : ''; ?>>
                    <?php echo clean($opt[0]); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <button type="button" class="btn btn-secondary btn-filter-toggle" id="filter-toggle" aria-expanded="false" aria-controls="filter-panel">
        <i class="fa-solid fa-sliders" aria-hidden="true"></i> Filters<?php echo $filterCount > 0 ? ' (' . $filterCount . ')' : ''; ?>
    </button>
</div>

<div class="shop-layout">

    <!-- ============ Filter sidebar ============ -->
    <aside class="filter-panel card" id="filter-panel">
        <div class="filter-block">
            <h3><i class="fa-solid fa-layer-group" aria-hidden="true"></i> Category</h3>
            <label class="filter-option">
                <input type="radio" name="category" value="" form="shop-filters" data-autosubmit
                       <?php echo $categoryId === 0 ? 'checked' : ''; ?>>
                <span>All Categories</span>
                <small><?php echo $totalMedicines; ?></small>
            </label>
            <?php foreach ($categories as $cat): ?>
                <label class="filter-option">
                    <input type="radio" name="category" value="<?php echo (int)$cat['id']; ?>" form="shop-filters" data-autosubmit
                           <?php echo $categoryId === (int)$cat['id'] ? 'checked' : ''; ?>>
                    <span><?php echo clean($cat['name']); ?></span>
                    <small><?php echo $categoryCounts[(int)$cat['id']] ?? 0; ?></small>
                </label>
            <?php endforeach; ?>
        </div>

        <div class="filter-block">
            <h3><i class="fa-solid fa-indian-rupee-sign" aria-hidden="true"></i> Price (₹)</h3>
            <div class="range-slider" id="price-slider"
                 data-min="<?php echo $boundsMin; ?>" data-max="<?php echo $boundsMax; ?>">
                <div class="track"></div>
                <div class="track-fill" id="price-fill"></div>
                <input type="range" id="price-min-range" min="<?php echo $boundsMin; ?>" max="<?php echo $boundsMax; ?>"
                       step="1" value="<?php echo min((float)$minShown, $boundsMax); ?>" aria-label="Minimum price">
                <input type="range" id="price-max-range" min="<?php echo $boundsMin; ?>" max="<?php echo $boundsMax; ?>"
                       step="1" value="<?php echo max((float)$maxShown, $boundsMin); ?>" aria-label="Maximum price">
            </div>
            <div class="price-fields">
                <input type="number" name="min_price" id="price-min" form="shop-filters" step="any" min="0"
                       value="<?php echo clean($minShown); ?>" aria-label="Minimum price">
                <span>to</span>
                <input type="number" name="max_price" id="price-max" form="shop-filters" step="any" min="0"
                       value="<?php echo clean($maxShown); ?>" aria-label="Maximum price">
            </div>
        </div>

        <div class="filter-block">
            <h3><i class="fa-solid fa-box" aria-hidden="true"></i> Availability</h3>
            <label class="filter-option">
                <input type="checkbox" name="instock" value="1" form="shop-filters" data-autosubmit
                       <?php echo $inStock ? 'checked' : ''; ?>>
                <span>In stock only</span>
            </label>
        </div>

        <button type="submit" form="shop-filters" class="btn btn-secondary filter-apply"><i class="fa-solid fa-filter" aria-hidden="true"></i> Apply Filters</button>
        <?php if ($chips): ?>
            <a href="medicines.php" class="filter-clear"><i class="fa-solid fa-rotate-left"></i> Clear All Filters</a>
        <?php endif; ?>
    </aside>

    <!-- ============ Results ============ -->
    <section class="shop-results" id="shop-results">

        <?php if (isset($_GET['added'])): ?>
            <div class="alert alert-success"><i class="fa-solid fa-circle-check" aria-hidden="true"></i> Added to cart.</div>
        <?php endif; ?>

        <?php if ($chips): ?>
            <div class="active-filters">
                <span class="text-muted">Applied:</span>
                <?php foreach ($chips as $chip): ?>
                    <span class="chip"><?php echo $chip[0]; ?>
                        <a href="<?php echo clean($chip[1]); ?>" title="Remove this filter" aria-label="Remove this filter">&times;</a>
                    </span>
                <?php endforeach; ?>
                <a href="medicines.php" class="chip-clear">Clear All</a>
            </div>
        <?php endif; ?>

        <?php if ($totalResults === 0): ?>
            <div class="empty-state card">
                <i class="fa-solid fa-magnifying-glass-minus"></i>
                <h3>No medicines found</h3>
                <p class="text-muted">Nothing matches your current search and filters. Try a different name, widen the price range or clear the filters.</p>
                <?php if ($chips): ?>
                    <a href="medicines.php" class="btn">Clear All Filters</a>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="grid shop-grid">
                <?php foreach ($medicines as $med): ?>
                    <?php $isLow = ($med['stock'] > 0 && $med['stock'] <= $med['min_threshold']); ?>
                    <div class="card med-card">
                        <div class="med-img-wrap">
                            <img src="<?php echo medicineImage($med['image']); ?>" alt="<?php echo clean($med['name']); ?>" class="med-img" loading="lazy">
                            <?php if ($med['requires_prescription']): ?>
                                <span class="rx-tag"><i class="fa-solid fa-prescription"></i> Rx Required</span>
                            <?php endif; ?>
                        </div>

                        <div class="med-body">
                            <?php if (!empty($med['category_name'])): ?>
                                <span class="med-cat"><?php echo clean($med['category_name']); ?></span>
                            <?php endif; ?>
                            <h3><?php echo clean($med['name']); ?></h3>
                            <p class="text-muted med-desc"><?php echo clean($med['description'] ?? ''); ?></p>
                        </div>

                        <div class="med-buy">
                            <p class="price">₹<?php echo number_format($med['price'], 2); ?></p>

                            <?php if ($med['stock'] <= 0): ?>
                                <p class="stock-badge stock-out">Out of stock</p>
                                <button type="button" class="btn btn-small" disabled>Out of Stock</button>
                            <?php else: ?>
                                <?php if ($isLow): ?>
                                    <p class="stock-badge stock-low">Only <?php echo (int)$med['stock']; ?> left in stock</p>
                                <?php else: ?>
                                    <p class="stock-badge stock-ok"><i class="fa-solid fa-circle-check"></i> In stock: <?php echo (int)$med['stock']; ?></p>
                                <?php endif; ?>

                                <form method="post" action="add_to_cart.php" class="buy-form">
                                    <input type="hidden" name="medicine_id" value="<?php echo (int)$med['id']; ?>">
                                    <?php echo csrfField(); ?>
                                    <input type="hidden" name="return_qs" value="<?php echo clean($returnQs); ?>">
                                    <input type="number" name="qty" value="1" min="1" max="<?php echo (int)$med['stock']; ?>"
                                           aria-label="Quantity for <?php echo clean($med['name']); ?>">
                                    <button type="submit" class="btn btn-small"><i class="fa-solid fa-cart-plus" aria-hidden="true"></i> Add to Cart</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php if ($totalPages > 1): ?>
                <?php
                // Page numbers: first, last and a few around the current page
                $shown = [];
                for ($p = 1; $p <= $totalPages; $p++) {
                    if ($p === 1 || $p === $totalPages || abs($p - $page) <= 1) { $shown[] = $p; }
                }
                ?>
                <nav class="pagination" aria-label="Medicine pages">
                    <?php if ($page > 1): ?>
                        <a href="<?php echo clean(shopUrl($state, ['page' => $page - 1])); ?>#shop-results">&laquo; Prev</a>
                    <?php else: ?>
                        <span class="disabled">&laquo; Prev</span>
                    <?php endif; ?>

                    <?php $last = 0; foreach ($shown as $p): ?>
                        <?php if ($p - $last > 1): ?><span class="dots">&hellip;</span><?php endif; ?>
                        <?php if ($p === $page): ?>
                            <span class="current" aria-current="page"><?php echo $p; ?></span>
                        <?php else: ?>
                            <a href="<?php echo clean(shopUrl($state, ['page' => $p])); ?>#shop-results"><?php echo $p; ?></a>
                        <?php endif; ?>
                        <?php $last = $p; ?>
                    <?php endforeach; ?>

                    <?php if ($page < $totalPages): ?>
                        <a href="<?php echo clean(shopUrl($state, ['page' => $page + 1])); ?>#shop-results">Next &raquo;</a>
                    <?php else: ?>
                        <span class="disabled">Next &raquo;</span>
                    <?php endif; ?>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
    </section>
</div>

<script src="assets/js/medicines.js"></script>

<?php include 'includes/footer.php'; ?>
