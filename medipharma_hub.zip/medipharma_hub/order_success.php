<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
requireCustomerLogin();

$orderId = (int) ($_GET['order_id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
$stmt->execute([$orderId, $_SESSION['user_id']]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    redirect('medicines.php');
}

include 'includes/header.php';
?>

<div class="form-box" style="text-align:center;">
    <h1>Order Placed!</h1>
    <p class="alert alert-success">Your order #<?php echo $order['id']; ?> has been placed successfully.</p>
    <p class="text-muted">Total: ₹<?php echo number_format($order['total_amount'], 2); ?></p>
    <p class="text-muted">Status: <?php echo ucfirst($order['status']); ?></p>
    <a href="medicines.php" class="btn mt-24">Continue Shopping</a>
    <a href="my_orders.php" class="btn btn-outline mt-24">View My Orders</a>
</div>

<?php include 'includes/footer.php'; ?>
