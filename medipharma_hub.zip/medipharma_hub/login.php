<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = clean($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['name']    = $user['full_name'];
        $_SESSION['role']    = $user['role'];

        if ($user['role'] === 'admin') {
            redirect('admin/dashboard.php');
        } else {
            redirect('medicines.php');
        }
    } else {
        $error = "Incorrect email or password.";
    }
}

include 'includes/header.php';
?>

<h1>Log in</h1>
<div class="form-box">
    <?php if (isset($_GET['registered'])): ?>
        <div class="alert alert-success">Account created successfully. Please log in.</div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="post">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required>

        <label for="password">Password</label>
        <div class="password-field">
            <input type="password" id="password" name="password" required>
            <button type="button" class="password-toggle" data-target="password"
                    aria-label="Show password" title="Show password" aria-pressed="false">
                <i class="fa-solid fa-eye" aria-hidden="true"></i>
            </button>
        </div>

        <button type="submit" class="btn mt-24"><i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i> Log In</button>
    </form>
    <p class="text-muted mt-24">New here? <a href="register.php">Create an account</a></p>
</div>

<script src="assets/js/auth.js"></script>

<?php include 'includes/footer.php'; ?>
