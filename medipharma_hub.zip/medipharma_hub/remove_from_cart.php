<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
requireCustomerLogin();

// Removing an item changes the cart, so it must be a POST with a valid CSRF token
// (a plain link such as remove_from_cart.php?id=3 no longer changes anything).
if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf($_POST['csrf_token'] ?? '')) {
    $id = (int) ($_POST['id'] ?? 0);
    if (isset($_SESSION['cart'][$id])) {
        unset($_SESSION['cart'][$id]);
    }
}
redirect('cart.php');
