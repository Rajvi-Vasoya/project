-- =========================================================
-- MEDIPHARMA HUB - Clean final seed data
-- 12 categories / 127 unique products
-- Header/UI files are not modified by this database update.
-- =========================================================

CREATE DATABASE IF NOT EXISTS medipharma_hub;
USE medipharma_hub;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address VARCHAR(255),
    role ENUM('customer','admin') NOT NULL DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL
);
CREATE TABLE medicines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    category_id INT,
    description TEXT,
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    stock INT NOT NULL DEFAULT 0,
    min_threshold INT NOT NULL DEFAULT 10,
    requires_prescription TINYINT(1) NOT NULL DEFAULT 0,
    image VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
    prescription_path VARCHAR(255) DEFAULT NULL,
    status ENUM('pending','processing','shipped','delivered','cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    medicine_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (medicine_id) REFERENCES medicines(id) ON DELETE CASCADE
);

INSERT INTO users (full_name, email, password, role) VALUES
('Admin User', 'admin@medipharma.com', '$2y$10$FWLt2rYMCrpHBt2JX4pXdeIPuPVGnyos6kbn/BYlkIo1ho6BxoEPu', 'admin');

INSERT INTO categories (name) VALUES
('Nutritional Supplements'),
('Ayurvedic Products'),
('Diabetes Care'),
('Personal Care'),
('Eye, Ear, Nose & Dental Care'),
('Cough & Cold'),
('Health Care Devices'),
('Generic Medicines'),
('Heart Care'),
('Blood Pressure'),
('Kidney Care'),
('Elderly Care');

-- ---------- Category 1: Nutritional Supplements ----------
INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image) VALUES
('Vitamin C Tablets', 1, 'Helps support the immune system and provides antioxidant protection.', 100.00, 45, 10, 0, 'vitamin-c-tablets.jpg'),
('Vitamin D3 Tablets', 1, 'Supports healthy bones, teeth, and normal calcium absorption.', 100.00, 60, 10, 0, 'vitamin-d3-tablets.jpg'),
('Multivitamin Tablets', 1, 'Provides essential vitamins and minerals to support overall health.', 100.00, 60, 10, 0, 'multivitamin-tablets.jpg'),
('Calcium + Vitamin D3 Tablets', 1, 'Helps maintain strong bones and supports calcium absorption.', 100.00, 60, 10, 0, 'calcium-vitamin-d3-tablets.jpg'),
('Iron + Folic Acid Tablets', 1, 'Supports red blood cell formation and healthy iron levels.', 100.00, 60, 10, 0, 'iron-folic-acid-tablets.jpg'),
('Zinc Tablets', 1, 'Supports immune function and normal body growth.', 100.00, 45, 10, 0, 'zinc-tablets.jpg'),
('Magnesium Tablets', 1, 'Supports normal muscle and nerve function and energy production.', 100.00, 60, 10, 0, 'magnesium-tablets.jpg'),
('Omega-3 Fish Oil Capsules', 1, 'Provides omega-3 fatty acids that support heart and general health.', 450.00, 60, 10, 0, 'omega-3-fish-oil-capsules.jpg'),
('Protein Powder', 1, 'Provides protein to support muscle growth, repair, and daily nutritional needs.', 650.00, 60, 10, 0, 'protein-powder.jpg'),
('ORS / Electrolyte Powder', 1, 'Helps replace fluids and electrolytes lost due to dehydration.', 120.00, 60, 10, 0, 'ors-electrolyte-powder.jpg'),
('Vitamin B-Complex Tablets', 1, 'Contains B vitamins that support energy metabolism and normal nerve function.', 100.00, 45, 10, 0, 'vitamin-b-complex-tablets.jpg'),
('Vitamin B12 Tablets', 1, 'Supports red blood cell formation and normal nervous-system function.', 100.00, 60, 10, 0, 'vitamin-b12-tablets.jpg'),
('Folic Acid Tablets', 1, 'Supports healthy cell formation and red blood cell production.', 100.00, 60, 10, 0, 'folic-acid-tablets.jpg'),
('Vitamin E Capsules', 1, 'Provides antioxidant support and helps protect cells from oxidative damage.', 180.00, 60, 10, 0, 'vitamin-e-capsules.jpg'),
('Biotin Tablets', 1, 'Supports normal metabolism and contributes to healthy hair, skin, and nails.', 100.00, 60, 10, 0, 'biotin-tablets.jpg');

-- ---------- Category 2: Ayurvedic Products ----------
INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image) VALUES
('Ashwagandha Tablets', 2, 'Traditionally used to support general wellness, energy, and stress management.', 100.00, 45, 10, 0, 'ashwagandha-tablets.jpg'),
('Triphala Tablets', 2, 'Traditionally used to support digestion and regular bowel function.', 100.00, 60, 10, 0, 'triphala-tablets.jpg'),
('Amla Tablets', 2, 'A traditional source of vitamin C and commonly used for general wellness.', 100.00, 60, 10, 0, 'amla-tablets.jpg'),
('Giloy Tablets', 2, 'Traditionally used as a herbal wellness supplement to support immunity.', 100.00, 60, 10, 0, 'giloy-tablets.jpg'),
('Turmeric Capsules', 2, 'Traditionally used for its antioxidant and anti-inflammatory properties.', 180.00, 60, 10, 0, 'turmeric-capsules.jpg'),
('Brahmi Tablets', 2, 'Traditionally used to support memory, concentration, and mental wellness.', 100.00, 45, 10, 0, 'brahmi-tablets.jpg'),
('Neem Tablets', 2, 'Traditionally used for general wellness and skin health.', 100.00, 60, 10, 0, 'neem-tablets.jpg'),
('Tulsi Tablets', 2, 'Traditionally used to support respiratory wellness and immunity.', 100.00, 60, 10, 0, 'tulsi-tablets.jpg'),
('Arjuna Tablets', 2, 'Traditionally used in Ayurveda for cardiovascular wellness.', 100.00, 60, 10, 0, 'arjuna-tablets.jpg'),
('Shatavari Tablets', 2, 'Traditionally used to support women''s general health and wellness.', 100.00, 60, 10, 0, 'shatavari-tablets.jpg'),
('Moringa Tablets', 2, 'Provides plant-based nutrients and is used as a general nutritional supplement.', 100.00, 45, 10, 0, 'moringa-tablets.jpg'),
('Ginger Tablets', 2, 'Traditionally used to support digestion and occasional stomach discomfort.', 100.00, 60, 10, 0, 'ginger-tablets.jpg'),
('Patanjali Chyawanprash', 2, 'Traditional herbal formulation used as a general health and wellness supplement.', 220.00, 60, 10, 0, 'patanjali-chyawanprash.jpg'),
('Isabgol (Psyllium Husk)', 2, 'A natural source of dietary fiber commonly used to support bowel regularity.', 150.00, 60, 10, 0, 'isabgol-psyllium-husk.jpg'),
('Aloe Vera Juice', 2, 'Traditionally consumed as a herbal wellness product and for digestive support.', 220.00, 60, 10, 0, 'aloe-vera-juice.jpg');

-- ---------- Category 3: Diabetes Care ----------
INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image) VALUES
('Metformin Tablets', 3, 'Helps control blood sugar levels and is commonly used for Type 2 diabetes.', 100.00, 45, 10, 1, 'metformin-tablets.jpg'),
('Glimepiride Tablets', 3, 'Helps the body release insulin and lower blood glucose levels.', 100.00, 60, 10, 1, 'glimepiride-tablets.jpg'),
('Gliclazide Tablets', 3, 'Helps stimulate insulin release to control blood sugar.', 100.00, 60, 10, 1, 'gliclazide-tablets.jpg'),
('Sitagliptin Tablets', 3, 'Helps improve blood sugar control by supporting the body''s natural insulin response.', 100.00, 60, 10, 1, 'sitagliptin-tablets.jpg'),
('Empagliflozin Tablets', 3, 'Helps reduce blood glucose by increasing removal of glucose through urine.', 100.00, 60, 10, 1, 'empagliflozin-tablets.jpg'),
('Insulin Injection', 3, 'Replaces or supplements insulin in people who need insulin therapy.', 320.00, 45, 10, 1, 'insulin-injection.jpg'),
('Glucose Test Strips', 3, 'Used with a blood glucose meter to check blood sugar levels.', 150.00, 60, 10, 0, 'glucose-test-strips.jpg'),
('Blood Glucose Meter', 3, 'A device used to monitor blood glucose levels at home.', 850.00, 60, 10, 0, 'blood-glucose-meter.jpg');

-- ---------- Category 4: Personal Care ----------
INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image) VALUES
('Antiseptic Liquid', 4, 'Used to clean minor cuts, wounds, and protect against germs.', 150.00, 45, 10, 0, 'antiseptic-liquid.jpg'),
('Antiseptic Cream', 4, 'Helps protect minor cuts, burns, and skin injuries from infection.', 120.00, 60, 10, 0, 'antiseptic-cream.jpg'),
('Moisturizing Cream', 4, 'Helps keep the skin soft, smooth, and hydrated.', 120.00, 60, 10, 0, 'moisturizing-cream.jpg'),
('Sunscreen Lotion', 4, 'Helps protect the skin from harmful UV rays.', 120.00, 60, 10, 0, 'sunscreen-lotion.jpg'),
('Lip Balm', 4, 'Helps moisturize and protect dry or chapped lips.', 120.00, 60, 10, 0, 'lip-balm.jpg'),
('Hand Sanitizer', 4, 'Helps reduce germs on the hands when soap and water are not available.', 120.00, 45, 10, 0, 'hand-sanitizer.jpg'),
('Hand Wash', 4, 'Used to clean hands and remove dirt and germs.', 120.00, 60, 10, 0, 'hand-wash.jpg'),
('Body Lotion', 4, 'Helps moisturize and prevent dryness of the skin.', 120.00, 60, 10, 0, 'body-lotion.jpg'),
('Face Wash', 4, 'Used to clean the face and remove excess oil, dirt, and impurities.', 120.00, 60, 10, 0, 'face-wash.jpg'),
('Anti-Dandruff Shampoo', 4, 'Helps control dandruff and reduce scalp flaking.', 120.00, 60, 10, 0, 'anti-dandruff-shampoo.jpg'),
('Toothpaste', 4, 'Used for cleaning teeth and maintaining oral hygiene.', 120.00, 45, 10, 0, 'toothpaste.jpg'),
('Petroleum Jelly', 4, 'Helps protect and moisturize dry or cracked skin.', 150.00, 60, 10, 0, 'petroleum-jelly.jpg'),
('Aloe Vera Gel', 4, 'Used to moisturize and soothe the skin.', 120.00, 60, 10, 0, 'aloe-vera-gel.jpg'),
('Sanitary Pads', 4, 'Used for menstrual hygiene and protection during periods.', 120.00, 60, 10, 0, 'sanitary-pads.jpg');

-- ---------- Category 5: Eye, Ear, Nose & Dental Care ----------
INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image) VALUES
('Lubricating Eye Drops', 5, 'Help relieve dry, irritated, or tired eyes.', 120.00, 45, 10, 0, 'lubricating-eye-drops.jpg'),
('Artificial Tears', 5, 'Provide moisture and temporary relief from dry eyes.', 150.00, 60, 10, 0, 'artificial-tears.jpg'),
('Anti-Allergy Eye Drops', 5, 'Help relieve itching, watering, and redness caused by allergies.', 120.00, 60, 10, 0, 'anti-allergy-eye-drops.jpg'),
('Eye Wash', 5, 'Used to gently rinse the eyes and remove minor irritants.', 120.00, 60, 10, 0, 'eye-wash.jpg'),
('Ear Drops', 5, 'Used for specific ear conditions such as wax buildup or irritation, depending on ingredients.', 120.00, 60, 10, 0, 'ear-drops.jpg'),
('Ear Wax Removal Drops', 5, 'Help soften hardened earwax for easier removal.', 120.00, 45, 10, 0, 'ear-wax-removal-drops.jpg'),
('Ear Cleaning Solution', 5, 'Used for external ear hygiene.', 120.00, 60, 10, 0, 'ear-cleaning-solution.jpg'),
('Saline Nasal Drops', 5, 'Help moisturize the nasal passages and relieve dryness.', 120.00, 60, 10, 0, 'saline-nasal-drops.jpg'),
('Saline Nasal Spray', 5, 'Helps clean and moisturize the nose and may relieve nasal congestion.', 120.00, 60, 10, 0, 'saline-nasal-spray.jpg'),
('Nasal Decongestant Spray', 5, 'Provides temporary relief from a blocked or stuffy nose.', 120.00, 60, 10, 0, 'nasal-decongestant-spray.jpg'),
('Fluoride Toothpaste', 5, 'Helps clean teeth and prevent tooth decay.', 120.00, 45, 10, 0, 'fluoride-toothpaste.jpg'),
('Sensitive Teeth Toothpaste', 5, 'Helps reduce sensitivity to hot, cold, or sweet foods.', 120.00, 60, 10, 0, 'sensitive-teeth-toothpaste.jpg'),
('Mouthwash', 5, 'Helps clean the mouth and maintain fresh breath.', 120.00, 60, 10, 0, 'mouthwash.jpg'),
('Dental Floss', 5, 'Helps remove food particles and plaque between teeth.', 150.00, 60, 10, 0, 'dental-floss.jpg'),
('Toothbrush', 5, 'Used for daily cleaning of teeth and gums.', 150.00, 60, 10, 0, 'toothbrush.jpg');

-- ---------- Category 6: Cough & Cold ----------
INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image) VALUES
('Cough Syrup', 6, 'Helps provide temporary relief from cough and throat irritation.', 120.00, 45, 10, 0, 'cough-syrup.jpg'),
('Dry Cough Syrup', 6, 'Helps relieve dry, irritating coughs.', 120.00, 60, 10, 0, 'dry-cough-syrup.jpg'),
('Expectorant Cough Syrup', 6, 'Helps loosen mucus and make phlegm easier to clear.', 120.00, 60, 10, 0, 'expectorant-cough-syrup.jpg'),
('Cough Lozenges', 6, 'Help soothe an irritated or sore throat and reduce coughing discomfort.', 120.00, 60, 10, 0, 'cough-lozenges.jpg'),
('Paracetamol (PCM) Tablets', 6, 'Used to reduce fever and relieve mild aches and pains associated with colds.', 100.00, 60, 10, 0, 'paracetamol-pcm-tablets.jpg'),
('Vapor Rub', 6, 'Applied externally to provide a cooling sensation and temporary comfort during cough and cold symptoms.', 150.00, 45, 10, 0, 'vapor-rub.jpg');

-- ---------- Category 7: Health Care Devices ----------
INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image) VALUES
('Digital Thermometer', 7, 'Used to measure body temperature quickly and easily.', 250.00, 45, 10, 0, 'digital-thermometer.jpg'),
('Blood Pressure Monitor', 7, 'Used to measure blood pressure at home.', 1200.00, 60, 10, 0, 'blood-pressure-monitor.jpg'),
('Pulse Oximeter', 7, 'Measures blood oxygen saturation and pulse rate.', 900.00, 60, 10, 0, 'pulse-oximeter.jpg'),
('Nebulizer Machine', 7, 'Converts liquid medicine into a mist that can be inhaled through a mask or mouthpiece.', 1600.00, 60, 10, 0, 'nebulizer-machine.jpg'),
('Digital Weighing Scale', 7, 'Used to measure body weight.', 150.00, 60, 10, 0, 'digital-weighing-scale.jpg'),
('Heating Pad', 7, 'Provides gentle heat to help relieve minor muscle aches and stiffness.', 500.00, 45, 10, 0, 'heating-pad.jpg'),
('First Aid Kit', 7, 'Contains basic medical supplies for treating minor injuries.', 150.00, 60, 10, 0, 'first-aid-kit.jpg'),
('Medicine Pill Box', 7, 'Helps organize medicines according to days or doses.', 150.00, 60, 10, 0, 'medicine-pill-box.jpg'),
('Elastic Crepe Bandage', 7, 'Provides compression and support for minor sprains and strains.', 150.00, 60, 10, 0, 'elastic-crepe-bandage.jpg');

-- ---------- Category 8: Generic Medicines ----------
INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image) VALUES
('Ibuprofen Tablets', 8, 'Used to relieve pain, inflammation, and fever.', 100.00, 45, 10, 0, 'ibuprofen-tablets.jpg'),
('Cetirizine Tablets', 8, 'Used to relieve allergy symptoms such as sneezing, itching, and runny nose.', 100.00, 60, 10, 0, 'cetirizine-tablets.jpg'),
('Omeprazole Capsules', 8, 'Helps reduce excess stomach acid and is used for acid-related stomach problems.', 180.00, 60, 10, 0, 'omeprazole-capsules.jpg'),
('Pantoprazole Tablets', 8, 'Helps reduce stomach acid and is commonly used for acidity and acid reflux.', 100.00, 60, 10, 0, 'pantoprazole-tablets.jpg'),
('Antacid Suspension', 8, 'Provides temporary relief from acidity, heartburn, and indigestion.', 150.00, 60, 10, 0, 'antacid-suspension.jpg'),
('Ondansetron Tablets', 8, 'Used to prevent and control nausea and vomiting.', 100.00, 45, 10, 1, 'ondansetron-tablets.jpg'),
('Diclofenac Tablets', 8, 'Used to relieve pain and inflammation.', 100.00, 60, 10, 1, 'diclofenac-tablets.jpg'),
('Loperamide Tablets', 8, 'Used for short-term control of certain types of diarrhea.', 100.00, 60, 10, 0, 'loperamide-tablets.jpg'),
('Clotrimazole Cream', 8, 'An antifungal medicine used to treat certain fungal skin infections.', 120.00, 60, 10, 0, 'clotrimazole-cream.jpg'),
('Calamine Lotion', 8, 'Helps soothe minor skin irritation, itching, and discomfort.', 120.00, 60, 10, 0, 'calamine-lotion.jpg');

-- ---------- Category 9: Heart Care ----------
INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image) VALUES
('Atorvastatin Tablets', 9, 'Helps lower cholesterol and reduce the risk of cardiovascular problems.', 100.00, 45, 10, 1, 'atorvastatin-tablets.jpg'),
('Rosuvastatin Tablets', 9, 'Helps lower LDL cholesterol and manage high cholesterol levels.', 100.00, 60, 10, 1, 'rosuvastatin-tablets.jpg'),
('Aspirin Tablets', 9, 'At specific low doses, may be prescribed to reduce blood-clot risk in certain heart conditions.', 100.00, 60, 10, 1, 'aspirin-tablets.jpg'),
('Clopidogrel Tablets', 9, 'Helps prevent blood clots in people with certain cardiovascular conditions.', 100.00, 60, 10, 1, 'clopidogrel-tablets.jpg'),
('Furosemide Tablets', 9, 'Helps remove excess fluid from the body and is used in certain heart conditions.', 100.00, 60, 10, 1, 'furosemide-tablets.jpg'),
('Spironolactone Tablets', 9, 'A diuretic used in certain heart conditions and for managing fluid retention.', 100.00, 45, 10, 1, 'spironolactone-tablets.jpg'),
('Nitroglycerin Tablets/Spray', 9, 'Used under medical supervision for rapid relief of certain types of angina.', 100.00, 60, 10, 1, 'nitroglycerin-tablets-spray.jpg'),
('Isosorbide Mononitrate Tablets', 9, 'Used to help prevent episodes of angina in people with certain heart conditions.', 100.00, 60, 10, 1, 'isosorbide-mononitrate-tablets.jpg'),
('Digoxin Tablets', 9, 'Used for specific heart conditions, including certain cases of heart failure and abnormal heart rhythms.', 100.00, 60, 10, 1, 'digoxin-tablets.jpg'),
('Apixaban Tablets', 9, 'An anticoagulant used to prevent or treat blood clots in certain cardiovascular conditions.', 100.00, 60, 10, 1, 'apixaban-tablets.jpg');

-- ---------- Category 10: Blood Pressure ----------
INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image) VALUES
('Amlodipine Tablets', 10, 'Helps lower high blood pressure by relaxing blood vessels.', 100.00, 45, 10, 1, 'amlodipine-tablets.jpg'),
('Losartan Tablets', 10, 'Helps control high blood pressure by relaxing blood vessels.', 100.00, 60, 10, 1, 'losartan-tablets.jpg'),
('Telmisartan Tablets', 10, 'Used to manage high blood pressure and reduce cardiovascular risk in suitable patients.', 100.00, 60, 10, 1, 'telmisartan-tablets.jpg'),
('Olmesartan Tablets', 10, 'Helps lower blood pressure by relaxing and widening blood vessels.', 100.00, 60, 10, 1, 'olmesartan-tablets.jpg'),
('Enalapril Tablets', 10, 'Helps lower blood pressure and is used in certain heart conditions.', 100.00, 60, 10, 1, 'enalapril-tablets.jpg'),
('Metoprolol Tablets', 10, 'Helps lower blood pressure and control heart rate.', 100.00, 45, 10, 1, 'metoprolol-tablets.jpg'),
('Hydrochlorothiazide Tablets', 10, 'A diuretic that helps lower blood pressure by removing excess salt and water.', 100.00, 60, 10, 1, 'hydrochlorothiazide-tablets.jpg'),
('Nifedipine Tablets', 10, 'Helps relax blood vessels and lower blood pressure.', 100.00, 60, 10, 1, 'nifedipine-tablets.jpg'),
('Diltiazem Tablets', 10, 'Helps control blood pressure and heart rate.', 100.00, 60, 10, 1, 'diltiazem-tablets.jpg'),
('Prazosin Tablets', 10, 'Helps lower blood pressure by relaxing blood vessels.', 100.00, 60, 10, 1, 'prazosin-tablets.jpg');

-- ---------- Category 11: Kidney Care ----------
INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image) VALUES
('Allopurinol Tablets', 11, 'Helps reduce uric acid levels and is commonly used in the management of gout.', 100.00, 45, 10, 1, 'allopurinol-tablets.jpg'),
('Febuxostat Tablets', 11, 'Helps lower uric acid levels in people with high uric acid.', 100.00, 60, 10, 1, 'febuxostat-tablets.jpg'),
('Potassium Citrate Tablets', 11, 'Helps increase urinary citrate and may help prevent certain types of kidney stones.', 100.00, 60, 10, 1, 'potassium-citrate-tablets.jpg'),
('Sodium Bicarbonate Tablets', 11, 'May be prescribed to help manage excess acidity in the blood in certain kidney conditions.', 100.00, 60, 10, 1, 'sodium-bicarbonate-tablets.jpg'),
('Sevelamer Tablets', 11, 'Helps control high phosphate levels in people with chronic kidney disease.', 100.00, 60, 10, 1, 'sevelamer-tablets.jpg'),
('Calcium Acetate Tablets', 11, 'Helps reduce phosphate absorption in people with chronic kidney disease.', 100.00, 45, 10, 1, 'calcium-acetate-tablets.jpg'),
('Iron Tablets', 11, 'Used to prevent or treat iron deficiency when appropriate.', 100.00, 60, 10, 0, 'iron-tablets.jpg');

-- ---------- Category 12: Elderly Care ----------
INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image) VALUES
('Glucosamine + Chondroitin Tablets', 12, 'Commonly used as a nutritional supplement for joint health.', 100.00, 45, 10, 0, 'glucosamine-chondroitin-tablets.jpg'),
('Diclofenac Gel', 12, 'A topical pain-relief medicine used for certain localized muscle and joint pain.', 120.00, 60, 10, 0, 'diclofenac-gel.jpg'),
('Laxative Tablets', 12, 'Used for short-term relief of constipation when appropriate.', 100.00, 60, 10, 0, 'laxative-tablets.jpg'),
('Adult Diapers', 12, 'Provide absorbent protection for elderly people with urinary or bowel incontinence.', 500.00, 60, 10, 0, 'adult-diapers.jpg'),
('Adult Underpads', 12, 'Absorbent pads used to protect beds, chairs, and other surfaces.', 500.00, 60, 10, 0, 'adult-underpads.jpg'),
('Walking Stick', 12, 'Provides additional support and stability while walking.', 650.00, 45, 10, 0, 'walking-stick.jpg'),
('Walking Frame', 12, 'Provides greater stability for people who need walking assistance.', 3500.00, 60, 10, 0, 'walking-frame.jpg'),
('Wheelchair', 12, 'Provides mobility assistance for people who have difficulty walking.', 3500.00, 60, 10, 0, 'wheelchair.jpg');
