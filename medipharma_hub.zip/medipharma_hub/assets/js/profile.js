// =========================================================
// profile.js -- My Profile page
// 1. Edit Profile / Cancel buttons switch between the read-only view and the form
// 2. checks the fields before saving (the server checks them again)
// =========================================================
(function () {
    var view    = document.getElementById('profile-view');
    var edit    = document.getElementById('profile-edit');
    var form    = document.getElementById('profile-form');
    var editBtn = document.getElementById('profile-edit-btn');
    var cancel  = document.getElementById('profile-cancel-btn');
    if (!view || !edit || !form) { return; }

    function openEdit() {
        view.hidden = true;
        edit.hidden = false;
        if (editBtn) { editBtn.setAttribute('aria-expanded', 'true'); }
        document.getElementById('full_name').focus();
    }
    function closeEdit() {
        form.reset();                      // forget unsaved changes
        clearErrors();
        edit.hidden = true;
        view.hidden = false;
        if (editBtn) { editBtn.setAttribute('aria-expanded', 'false'); editBtn.focus(); }
    }
    if (editBtn) { editBtn.addEventListener('click', openEdit); }
    if (cancel)  { cancel.addEventListener('click', closeEdit); }

    // ---- validation ----
    function setError(name, text) {
        var input = form.elements[name];
        var box   = form.querySelector('[data-error-for="' + name + '"]');
        if (!box || !input) { return; }
        box.textContent = text;
        box.hidden = (text === '');
        input.setAttribute('aria-invalid', text === '' ? 'false' : 'true');
    }
    function clearErrors() {
        ['full_name', 'email', 'phone', 'address'].forEach(function (n) { setError(n, ''); });
    }

    function validate() {
        var v = {
            full_name: form.elements['full_name'].value.trim(),
            email:     form.elements['email'].value.trim(),
            phone:     form.elements['phone'].value.trim(),
            address:   form.elements['address'].value.trim()
        };
        var digits = v.phone.replace(/\D/g, '');
        var errors = {};

        if (v.full_name.length < 2 || v.full_name.length > 100) {
            errors.full_name = 'Please enter your full name (2 to 100 characters).';
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email) || v.email.length > 150) {
            errors.email = 'Please enter a valid email address.';
        }
        if (!/^\+?[0-9][0-9\s\-()]*$/.test(v.phone) || digits.length < 7 || digits.length > 15 || v.phone.length > 20) {
            errors.phone = 'Please enter a valid phone number (7 to 15 digits; you may use + - ( ) and spaces).';
        }
        if (v.address.length < 5 || v.address.length > 255) {
            errors.address = 'Please enter your delivery address (5 to 255 characters).';
        }
        return errors;
    }

    form.addEventListener('submit', function (event) {
        var errors = validate();
        var firstBad = null;
        ['full_name', 'email', 'phone', 'address'].forEach(function (name) {
            setError(name, errors[name] || '');
            if (errors[name] && !firstBad) { firstBad = name; }
        });
        if (firstBad) {
            event.preventDefault();
            form.elements[firstBad].focus();
        }
    });

    // clear a field's message as soon as the visitor starts fixing it
    ['full_name', 'email', 'phone', 'address'].forEach(function (name) {
        form.elements[name].addEventListener('input', function () { setError(name, ''); });
    });
})();
