// =========================================================
// cart.js -- plus / minus / remove buttons on cart.php
// Sends the change to update_cart.php (which re-checks the stock and the
// real price in the database) and then refreshes the page content from the
// server's answer: row subtotal, cart total, header cart count, and the
// prescription box (shown only while a prescription-only medicine is in the cart).
// Without JavaScript the same buttons still work: the form just reloads the page.
// =========================================================
(function () {
    var content = document.getElementById('cart-content');
    if (!content) { return; }

    var endpoint  = content.getAttribute('data-endpoint');
    var message   = document.getElementById('cart-message');
    var emptyText = document.getElementById('cart-empty');
    var totalEl   = document.getElementById('cart-total');
    var countEl   = document.getElementById('cart-count');
    var rxBox     = document.getElementById('rx-section');
    var rxFields  = document.getElementById('rx-fieldset');
    var busy = false;
    var hideTimer = null;

    function showMessage(text, ok) {
        if (!message || !text) { return; }
        message.textContent = text;
        message.className = 'alert ' + (ok ? 'alert-success' : 'alert-warning');
        message.hidden = false;
        clearTimeout(hideTimer);
        hideTimer = setTimeout(function () { message.hidden = true; }, 4000);
    }

    function setRx(needed) {
        if (!rxBox || !rxFields) { return; }
        rxBox.hidden = !needed;
        rxFields.disabled = !needed;
    }

    function applyResponse(data) {
        var rows = content.querySelectorAll('.cart-row');
        for (var i = 0; i < rows.length; i++) {
            var id = rows[i].getAttribute('data-id');
            var item = data.items ? data.items[id] : null;
            if (!item) {                       // removed (or no longer available)
                rows[i].parentNode.removeChild(rows[i]);
                continue;
            }
            rows[i].querySelector('.qty-value').textContent = item.qty;
            rows[i].querySelector('.row-subtotal').textContent = item.subtotal;
            rows[i].querySelector('.qty-minus').disabled = item.qty <= 1;
            rows[i].querySelector('.qty-plus').disabled = !item.can_increase;
        }
        if (totalEl) { totalEl.textContent = data.total; }
        if (countEl) { countEl.textContent = data.count > 0 ? ' (' + data.count + ')' : ''; }
        setRx(!!data.needs_rx);

        if (data.empty) {
            content.hidden = true;
            if (emptyText) { emptyText.hidden = false; }
        }
    }

    content.addEventListener('click', function (event) {
        var button = event.target.closest ? event.target.closest('button[data-action]') : null;
        if (!button || !content.contains(button)) { return; }
        event.preventDefault();
        if (busy || button.disabled) { return; }

        var form = button.form;
        var body = new URLSearchParams();
        body.append('csrf_token', form.elements['csrf_token'].value);
        body.append('medicine_id', form.elements['medicine_id'].value);
        body.append('action', button.getAttribute('data-action'));

        busy = true;
        content.classList.add('is-updating');

        fetch(endpoint, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            },
            body: body.toString()
        })
        .then(function (response) { return response.json(); })
        .then(function (data) {
            if (data.items) { applyResponse(data); }
            if (data.message) { showMessage(data.message, data.ok); }
            if (data.notices && data.notices.length) { showMessage(data.notices.join(' '), false); }
        })
        .catch(function () {
            showMessage('Could not update your cart. Please refresh the page and try again.', false);
        })
        .then(function () {
            busy = false;
            content.classList.remove('is-updating');
        });
    });
})();
