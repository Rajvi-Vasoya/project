// =========================================================
// medicines.js -- small helpers for the medicine shopping page
// 1. keeps the dual price slider and the two price boxes in sync
// 2. submits the filter form when a category / sort / stock option changes
//    (and keeps the address bar tidy by leaving out unused fields)
// 3. opens and closes the filter panel on mobile
// =========================================================
(function () {
    // Lets the CSS know JavaScript is running (used for the mobile filter panel)
    document.documentElement.classList.add('js');

    var form     = document.getElementById('shop-filters');
    var minRange = document.getElementById('price-min-range');
    var maxRange = document.getElementById('price-max-range');
    var minBox   = document.getElementById('price-min');
    var maxBox   = document.getElementById('price-max');
    var fill     = document.getElementById('price-fill');
    var lo = minRange ? parseFloat(minRange.min) : 0;   // cheapest price in the store
    var hi = minRange ? parseFloat(minRange.max) : 0;   // most expensive price in the store

    // ---- 1. Price slider ----
    if (minRange && maxRange && minBox && maxBox && fill) {

        // Colours the part of the bar between the two handles
        function updateFill() {
            var a = (parseFloat(minRange.value) - lo) / (hi - lo) * 100;
            var b = (parseFloat(maxRange.value) - lo) / (hi - lo) * 100;
            fill.style.left  = a + '%';
            fill.style.width = Math.max(0, b - a) + '%';
            // when both handles meet at the right end, keep the min handle reachable
            minRange.style.zIndex = (parseFloat(minRange.value) >= hi - 1) ? 5 : 3;
            maxRange.style.zIndex = 4;
        }

        minRange.addEventListener('input', function () {
            if (parseFloat(minRange.value) > parseFloat(maxRange.value)) {
                minRange.value = maxRange.value;
            }
            minBox.value = minRange.value;
            updateFill();
        });
        maxRange.addEventListener('input', function () {
            if (parseFloat(maxRange.value) < parseFloat(minRange.value)) {
                maxRange.value = minRange.value;
            }
            maxBox.value = maxRange.value;
            updateFill();
        });

        // Typing in the boxes moves the handles
        minBox.addEventListener('input', function () {
            var v = parseFloat(minBox.value);
            if (!isNaN(v)) {
                minRange.value = Math.min(Math.max(v, lo), parseFloat(maxRange.value));
                updateFill();
            }
        });
        maxBox.addEventListener('input', function () {
            var v = parseFloat(maxBox.value);
            if (!isNaN(v)) {
                maxRange.value = Math.max(Math.min(v, hi), parseFloat(minRange.value));
                updateFill();
            }
        });

        updateFill();
    }

    // ---- 2. Submitting the filter form ----
    // Fields that are empty or still at their default are switched off just before
    // submitting, so the address bar only shows the filters that are really used.
    var switchedOff = [];
    function tidyForm() {
        var fields = form.elements;
        for (var i = 0; i < fields.length; i++) {
            var el = fields[i];
            var skip = false;
            if (el.name === 'q' && el.value.trim() === '') { skip = true; }
            if (el.name === 'category' && el.value === '') { skip = true; }
            if (el.name === 'sort' && el.value === 'name_asc') { skip = true; }
            if (minBox && el === minBox && (isNaN(parseFloat(el.value)) || parseFloat(el.value) <= lo)) { skip = true; }
            if (maxBox && el === maxBox && (isNaN(parseFloat(el.value)) || parseFloat(el.value) >= hi)) { skip = true; }
            if (skip && !el.disabled) {
                el.disabled = true;
                switchedOff.push(el);
            }
        }
    }
    // If the visitor presses the browser Back button, switch those fields on again
    window.addEventListener('pageshow', function () {
        while (switchedOff.length) { switchedOff.pop().disabled = false; }
    });

    if (form) {
        form.addEventListener('submit', tidyForm);   // Search / Apply Filters buttons, Enter key

        var autoFields = document.querySelectorAll('[data-autosubmit]');
        for (var i = 0; i < autoFields.length; i++) {
            autoFields[i].addEventListener('change', function () {
                tidyForm();
                form.submit();
            });
        }
    }

    // ---- 3. Mobile filter panel ----
    var toggle = document.getElementById('filter-toggle');
    var panel  = document.getElementById('filter-panel');
    if (toggle && panel) {
        toggle.addEventListener('click', function () {
            var open = panel.classList.toggle('open');
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    }
})();
