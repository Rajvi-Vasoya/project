// =========================================================
// auth.js -- small helpers for the login and registration forms
// 1. show / hide password buttons (eye icon)
// 2. "Confirm Password" must match "Password" before the form is sent
//    (the server checks this again, so this is only a convenience)
// =========================================================
(function () {
    // ---- 1. Show / hide password ----
    var toggles = document.querySelectorAll('.password-toggle');
    for (var i = 0; i < toggles.length; i++) {
        toggles[i].addEventListener('click', function () {
            var input = document.getElementById(this.getAttribute('data-target'));
            var icon  = this.querySelector('i');
            if (!input) { return; }

            var show = (input.type === 'password');
            input.type = show ? 'text' : 'password';
            this.setAttribute('aria-pressed', show ? 'true' : 'false');
            this.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
            this.setAttribute('title', show ? 'Hide password' : 'Show password');
            if (icon) {
                icon.className = show ? 'fa-solid fa-eye-slash' : 'fa-solid fa-eye';
            }
            input.focus();
        });
    }

    // ---- 2. Password and Confirm Password must match ----
    var form    = document.getElementById('register-form');
    var pass    = document.getElementById('password');
    var confirm = document.getElementById('confirm_password');
    var message = document.getElementById('confirm-error');
    if (!form || !pass || !confirm || !message) { return; }

    function checkMatch(showWhenEmpty) {
        var mismatch = confirm.value !== pass.value && (confirm.value !== '' || showWhenEmpty);
        message.textContent = mismatch ? 'Password and Confirm Password do not match.' : '';
        message.hidden = !mismatch;
        confirm.setAttribute('aria-invalid', mismatch ? 'true' : 'false');
        return !mismatch;
    }

    confirm.addEventListener('input', function () { checkMatch(false); });
    pass.addEventListener('input', function () { if (confirm.value !== '') { checkMatch(false); } });

    form.addEventListener('submit', function (event) {
        if (!checkMatch(true)) {
            event.preventDefault();
            confirm.focus();
        }
    });
})();
