This folder stores uploaded prescription files. Safe to keep empty.
