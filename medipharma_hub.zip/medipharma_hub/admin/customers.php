<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireAdminLogin();

$customers = $pdo->query("
    SELECT u.*, COUNT(o.id) AS order_count, COALESCE(SUM(o.total_amount), 0) AS total_spent
    FROM users u
    LEFT JOIN orders o ON o.user_id = u.id
    WHERE u.role = 'customer'
    GROUP BY u.id
    ORDER BY u.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);

include '../includes/header.php';
include 'admin_nav.php';
?>

<h1>Manage Customers</h1>

<?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success">Customer account deleted.</div>
<?php endif; ?>

<table>
    <tr>
        <th>Name</th><th>Email</th><th>Phone</th><th>Address</th>
        <th>Orders</th><th>Total Spent</th><th>Joined</th><th>Actions</th>
    </tr>
    <?php if (empty($customers)): ?>
        <tr><td colspan="8" class="text-muted">No registered customers yet.</td></tr>
    <?php endif; ?>
    <?php foreach ($customers as $cust): ?>
        <tr>
            <td><?php echo clean($cust['full_name']); ?></td>
            <td><?php echo clean($cust['email']); ?></td>
            <td><?php echo clean($cust['phone'] ?: '-'); ?></td>
            <td><?php echo clean($cust['address'] ?: '-'); ?></td>
            <td><a href="orders.php?user_id=<?php echo $cust['id']; ?>"><?php echo $cust['order_count']; ?></a></td>
            <td>₹<?php echo number_format($cust['total_spent'], 2); ?></td>
            <td><?php echo date('d M Y', strtotime($cust['created_at'])); ?></td>
            <td>
                <a href="delete_customer.php?id=<?php echo $cust['id']; ?>"
                   onclick="return confirm('Delete this customer? Their orders will also be removed.');">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<?php include '../includes/footer.php'; ?>
