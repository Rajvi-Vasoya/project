<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireAdminLogin();

$error = '';

// Add a new category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_category'])) {
    $name = clean($_POST['name']);

    if ($name === '') {
        $error = "Category name cannot be empty.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM categories WHERE name = ?");
        $stmt->execute([$name]);
        if ($stmt->fetch()) {
            $error = "A category with this name already exists.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO categories (name) VALUES (?)");
            $stmt->execute([$name]);
            redirect('categories.php?added=1');
        }
    }
}

$categories = $pdo->query("
    SELECT c.*, COUNT(m.id) AS medicine_count
    FROM categories c
    LEFT JOIN medicines m ON m.category_id = c.id
    GROUP BY c.id
    ORDER BY c.name
")->fetchAll(PDO::FETCH_ASSOC);

include '../includes/header.php';
include 'admin_nav.php';
?>

<h1>Manage Categories</h1>

<?php if (isset($_GET['added'])): ?>
    <div class="alert alert-success">Category added.</div>
<?php endif; ?>
<?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success">Category deleted.</div>
<?php endif; ?>
<?php if (isset($_GET['blocked'])): ?>
    <div class="alert alert-error">This category still has medicines assigned to it. Move or delete those medicines first.</div>
<?php endif; ?>
<?php if ($error): ?>
    <div class="alert alert-error"><?php echo $error; ?></div>
<?php endif; ?>

<form method="post" class="inline-form">
    <div>
        <label for="name">New category name</label>
        <input type="text" id="name" name="name" placeholder="e.g. Skin Care" required>
    </div>
    <button type="submit" name="add_category" value="1" class="btn">+ Add Category</button>
</form>

<table>
    <tr>
        <th>Name</th><th>Medicines</th><th>Actions</th>
    </tr>
    <?php foreach ($categories as $cat): ?>
        <tr>
            <td><?php echo clean($cat['name']); ?></td>
            <td><?php echo $cat['medicine_count']; ?></td>
            <td>
                <a href="edit_category.php?id=<?php echo $cat['id']; ?>">Edit</a> |
                <a href="delete_category.php?id=<?php echo $cat['id']; ?>"
                   onclick="return confirm('Delete this category?');">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<?php include '../includes/footer.php'; ?>
