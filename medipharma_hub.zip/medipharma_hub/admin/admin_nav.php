<?php
// Reusable admin sub-navigation. Include this on every page inside /admin
// right after includes/header.php is included.
$adminNavCurrent = basename($_SERVER['PHP_SELF']);

function navActive($current, $pages) {
    return in_array($current, $pages) ? 'active' : '';
}
?>
<div class="admin-tabs">
    <a href="dashboard.php" class="<?php echo navActive($adminNavCurrent, ['dashboard.php']); ?>">
        <i class="fa-solid fa-gauge-high"></i> Dashboard
    </a>
    <a href="medicines.php" class="<?php echo navActive($adminNavCurrent, ['medicines.php', 'add_medicine.php', 'edit_medicine.php']); ?>">
        <i class="fa-solid fa-pills"></i> Medicines
    </a>
    <a href="categories.php" class="<?php echo navActive($adminNavCurrent, ['categories.php', 'edit_category.php']); ?>">
        <i class="fa-solid fa-layer-group"></i> Categories
    </a>
    <a href="orders.php" class="<?php echo navActive($adminNavCurrent, ['orders.php']); ?>">
        <i class="fa-solid fa-truck-medical"></i> Orders
    </a>
    <a href="customers.php" class="<?php echo navActive($adminNavCurrent, ['customers.php']); ?>">
        <i class="fa-solid fa-user-group"></i> Customers
    </a>
</div>
