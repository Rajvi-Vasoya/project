<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireAdminLogin();

// Update order status if the admin submits the status form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'])) {
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$_POST['status'], (int) $_POST['order_id']]);
    redirect('orders.php');
}

$filterUserId = (int) ($_GET['user_id'] ?? 0);

$sql = "
    SELECT o.*, u.full_name, u.email
    FROM orders o
    JOIN users u ON o.user_id = u.id
";
$params = [];
if ($filterUserId > 0) {
    $sql .= " WHERE o.user_id = ?";
    $params[] = $filterUserId;
}
$sql .= " ORDER BY o.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

include '../includes/header.php';
include 'admin_nav.php';
?>

<h1>All Orders</h1>

<?php if ($filterUserId > 0): ?>
    <div class="alert alert-warning flex-between">
        <span>Showing orders for <?php echo !empty($orders) ? clean($orders[0]['full_name']) : 'this customer'; ?> only.</span>
        <a href="orders.php">Clear filter</a>
    </div>
<?php endif; ?>

<table>
    <tr>
        <th>Order #</th><th>Customer</th><th>Total</th><th>Prescription</th><th>Status</th><th>Placed On</th>
    </tr>
    <?php foreach ($orders as $order): ?>
        <tr>
            <td>#<?php echo $order['id']; ?></td>
            <td><?php echo clean($order['full_name']); ?><br><span class="text-muted"><?php echo clean($order['email']); ?></span></td>
            <td>₹<?php echo number_format($order['total_amount'], 2); ?></td>
            <td>
                <?php if ($order['prescription_path']): ?>
                    <a href="../<?php echo clean($order['prescription_path']); ?>" target="_blank">View File</a>
                <?php else: ?>
                    <span class="text-muted">None</span>
                <?php endif; ?>
            </td>
            <td>
                <form method="post" style="display:flex; gap:6px;">
                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                    <select name="status">
                        <?php foreach (['pending','processing','shipped','delivered','cancelled'] as $status): ?>
                            <option value="<?php echo $status; ?>" <?php echo $order['status'] === $status ? 'selected' : ''; ?>>
                                <?php echo ucfirst($status); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="btn btn-small btn-secondary">Update</button>
                </form>
            </td>
            <td><?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?></td>
        </tr>
    <?php endforeach; ?>
</table>

<?php include '../includes/footer.php'; ?>
