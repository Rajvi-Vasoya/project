<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireAdminLogin();

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = clean($_POST['name']);
    $categoryId = (int) $_POST['category_id'];
    $description = clean($_POST['description']);
    $price = (float) $_POST['price'];
    $stock = (int) $_POST['stock'];
    $threshold = (int) $_POST['min_threshold'];
    $rx = isset($_POST['requires_prescription']) ? 1 : 0;

    if ($name === '' || $price < 0 || $stock < 0) {
        $error = "Please fill in the form correctly.";
    } else {
        // Optional photo
        list($image, $imgError) = saveMedicineImage($_FILES['image'] ?? null, $name);
        if ($imgError) {
            $error = $imgError;
        } else {
            $stmt = $pdo->prepare(
                "INSERT INTO medicines (name, category_id, description, price, stock, min_threshold, requires_prescription, image)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
            );
            $stmt->execute([$name, $categoryId, $description, $price, $stock, $threshold, $rx, $image]);
            redirect('medicines.php');
        }
    }
}

include '../includes/header.php';
include 'admin_nav.php';
?>

<h1>Add Medicine</h1>
<div class="form-box">
    <?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <label>Name *</label>
        <input type="text" name="name" required>

        <label>Category</label>
        <select name="category_id">
            <?php foreach ($categories as $cat): ?>
                <option value="<?php echo $cat['id']; ?>"><?php echo clean($cat['name']); ?></option>
            <?php endforeach; ?>
        </select>

        <label>Photo (JPG, PNG or WEBP, max 2MB)</label>
        <input type="file" name="image" accept="image/jpeg,image/png,image/webp">

        <label>Description</label>
        <textarea name="description" rows="3"></textarea>

        <label>Price (₹) *</label>
        <input type="number" step="0.01" name="price" required>

        <label>Stock Quantity *</label>
        <input type="number" name="stock" required>

        <label>Minimum Stock Threshold *</label>
        <input type="number" name="min_threshold" value="10" required>

        <label style="display:flex; align-items:center; gap:8px;">
            <input type="checkbox" name="requires_prescription" style="width:auto;"> Requires Prescription
        </label>

        <button type="submit" class="btn mt-24">Save Medicine</button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>
