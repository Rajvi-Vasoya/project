<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireAdminLogin();

$lowStock = getLowStockMedicines($pdo);

$totalMeds   = $pdo->query("SELECT COUNT(*) FROM medicines")->fetchColumn();
$totalOrders = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$pendingOrders = $pdo->query("SELECT COUNT(*) FROM orders WHERE status = 'pending'")->fetchColumn();
$totalCategories = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$totalCustomers  = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();

include '../includes/header.php';
include 'admin_nav.php';
?>

<h1>Admin Dashboard</h1>

<?php if (!empty($lowStock)): ?>
    <div class="low-stock-banner">
        <span class="badge">!</span>
        <div>
            <strong><?php echo count($lowStock); ?> medicine(s) are at or below their minimum stock threshold.</strong>
            <div><a href="medicines.php" style="color:#fff; text-decoration:underline;">Review low stock &rarr;</a></div>
        </div>
    </div>
<?php endif; ?>

<div class="grid">
    <div class="card">
        <h3><?php echo $totalMeds; ?></h3>
        <p class="text-muted">Total Medicines</p>
    </div>
    <div class="card">
        <h3><?php echo $totalOrders; ?></h3>
        <p class="text-muted">Total Orders</p>
    </div>
    <div class="card">
        <h3><?php echo $pendingOrders; ?></h3>
        <p class="text-muted">Pending Orders</p>
    </div>
    <div class="card">
        <h3><?php echo $totalCategories; ?></h3>
        <p class="text-muted">Categories</p>
    </div>
    <div class="card">
        <h3><?php echo $totalCustomers; ?></h3>
        <p class="text-muted">Registered Customers</p>
    </div>
</div>

<?php if (!empty($lowStock)): ?>
<h2 class="mt-24">Low Stock Details</h2>
<table>
    <tr><th>Medicine</th><th>Current Stock</th><th>Minimum Threshold</th></tr>
    <?php foreach ($lowStock as $med): ?>
        <tr>
            <td><?php echo clean($med['name']); ?></td>
            <td><?php echo $med['stock']; ?></td>
            <td><?php echo $med['min_threshold']; ?></td>
        </tr>
    <?php endforeach; ?>
</table>
<?php endif; ?>

<p class="mt-24">
    <a href="medicines.php" class="btn btn-secondary">Manage Medicines</a>
    <a href="categories.php" class="btn btn-secondary">Manage Categories</a>
    <a href="orders.php" class="btn btn-secondary">View Orders</a>
    <a href="customers.php" class="btn btn-secondary">Manage Customers</a>
</p>

<?php include '../includes/footer.php'; ?>
