<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireAdminLogin();

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM medicines WHERE id = ?");
$stmt->execute([$id]);
$med = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$med) {
    redirect('medicines.php');
}

$categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = clean($_POST['name']);
    $categoryId = (int) $_POST['category_id'];
    $description = clean($_POST['description']);
    $price = (float) $_POST['price'];
    $stock = (int) $_POST['stock'];
    $threshold = (int) $_POST['min_threshold'];
    $rx = isset($_POST['requires_prescription']) ? 1 : 0;

    if ($name === '' || $price < 0 || $stock < 0) {
        $error = "Please fill in the form correctly.";
    } else {
        // Keep the current photo unless a new one is uploaded
        list($newImage, $imgError) = saveMedicineImage($_FILES['image'] ?? null, $name);
        if ($imgError) {
            $error = $imgError;
        } else {
            $image = $newImage ?? $med['image'];
            $stmt = $pdo->prepare(
                "UPDATE medicines SET name=?, category_id=?, description=?, price=?, stock=?, min_threshold=?, requires_prescription=?, image=? WHERE id=?"
            );
            $stmt->execute([$name, $categoryId, $description, $price, $stock, $threshold, $rx, $image, $id]);
            if ($newImage !== null && $med['image'] !== $newImage) {
                deleteMedicineImage($med['image']);
            }
            redirect('medicines.php');
        }
    }
}

include '../includes/header.php';
include 'admin_nav.php';
?>

<h1>Edit Medicine</h1>
<div class="form-box">
    <?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $med['id']; ?>">

        <label>Name *</label>
        <input type="text" name="name" value="<?php echo clean($med['name']); ?>" required>

        <label>Category</label>
        <select name="category_id">
            <?php foreach ($categories as $cat): ?>
                <option value="<?php echo $cat['id']; ?>" <?php echo $cat['id'] == $med['category_id'] ? 'selected' : ''; ?>>
                    <?php echo clean($cat['name']); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Photo</label>
        <img src="<?php echo medicineImage($med['image'], '../'); ?>" alt="" class="thumb-lg">
        <input type="file" name="image" accept="image/jpeg,image/png,image/webp">
        <small class="text-muted">Leave empty to keep the current photo.</small>

        <label>Description</label>
        <textarea name="description" rows="3"><?php echo clean($med['description']); ?></textarea>

        <label>Price (₹) *</label>
        <input type="number" step="0.01" name="price" value="<?php echo $med['price']; ?>" required>

        <label>Stock Quantity *</label>
        <input type="number" name="stock" value="<?php echo $med['stock']; ?>" required>

        <label>Minimum Stock Threshold *</label>
        <input type="number" name="min_threshold" value="<?php echo $med['min_threshold']; ?>" required>

        <label style="display:flex; align-items:center; gap:8px;">
            <input type="checkbox" name="requires_prescription" style="width:auto;" <?php echo $med['requires_prescription'] ? 'checked' : ''; ?>>
            Requires Prescription
        </label>

        <button type="submit" class="btn mt-24">Update Medicine</button>
    </form>
</div>

<?php include '../includes/footer.php'; ?>
