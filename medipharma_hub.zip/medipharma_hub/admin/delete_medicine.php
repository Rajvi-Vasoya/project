<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireAdminLogin();

$id = (int) ($_GET['id'] ?? 0);
$stmt = $pdo->prepare("SELECT image FROM medicines WHERE id = ?");
$stmt->execute([$id]);
$image = $stmt->fetchColumn();

$stmt = $pdo->prepare("DELETE FROM medicines WHERE id = ?");
$stmt->execute([$id]);
deleteMedicineImage($image);

redirect('medicines.php?deleted=1');
