<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireAdminLogin();

$id = (int) ($_GET['id'] ?? 0);

// Safety check: never allow deleting an admin account through this page
$stmt = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$stmt->execute([$id]);
$role = $stmt->fetchColumn();

if ($role === 'customer') {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute([$id]);
}

redirect('customers.php?deleted=1');
