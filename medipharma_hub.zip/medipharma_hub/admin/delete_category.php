<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireAdminLogin();

$id = (int) ($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT COUNT(*) FROM medicines WHERE category_id = ?");
$stmt->execute([$id]);
$medicineCount = $stmt->fetchColumn();

if ($medicineCount > 0) {
    // Don't allow deleting a category that's still in use -- redirect with a warning instead
    redirect('categories.php?blocked=1');
}

$stmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
$stmt->execute([$id]);

redirect('categories.php?deleted=1');
