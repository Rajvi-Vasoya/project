<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireAdminLogin();

$id = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
$stmt->execute([$id]);
$category = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$category) {
    redirect('categories.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = clean($_POST['name']);

    if ($name === '') {
        $error = "Category name cannot be empty.";
    } else {
        $stmt = $pdo->prepare("SELECT id FROM categories WHERE name = ? AND id != ?");
        $stmt->execute([$name, $id]);
        if ($stmt->fetch()) {
            $error = "Another category already uses this name.";
        } else {
            $stmt = $pdo->prepare("UPDATE categories SET name = ? WHERE id = ?");
            $stmt->execute([$name, $id]);
            redirect('categories.php');
        }
    }
}

include '../includes/header.php';
include 'admin_nav.php';
?>

<h1>Edit Category</h1>
<div class="form-box">
    <?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>

    <form method="post">
        <input type="hidden" name="id" value="<?php echo $category['id']; ?>">

        <label>Name *</label>
        <input type="text" name="name" value="<?php echo clean($category['name']); ?>" required>

        <button type="submit" class="btn mt-24">Update Category</button>
    </form>
    <p class="text-muted mt-24"><a href="categories.php">Back to categories</a></p>
</div>

<?php include '../includes/footer.php'; ?>
