<?php
require_once '../config/db.php';
require_once '../includes/functions.php';
requireAdminLogin();

$medicines = $pdo->query("
    SELECT m.*, c.name AS category_name
    FROM medicines m
    LEFT JOIN categories c ON m.category_id = c.id
    ORDER BY m.name
")->fetchAll(PDO::FETCH_ASSOC);

include '../includes/header.php';
include 'admin_nav.php';
?>

<div class="flex-between">
    <h1>Manage Medicines</h1>
    <a href="add_medicine.php" class="btn">+ Add Medicine</a>
</div>

<?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success">Medicine deleted.</div>
<?php endif; ?>

<table>
    <tr>
        <th>Photo</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Threshold</th><th>Rx</th><th>Actions</th>
    </tr>
    <?php foreach ($medicines as $med): ?>
        <tr>
            <td><img src="<?php echo medicineImage($med['image'], '../'); ?>" alt="" class="thumb"></td>
            <td><?php echo clean($med['name']); ?></td>
            <td><?php echo clean($med['category_name'] ?? '-'); ?></td>
            <td>₹<?php echo number_format($med['price'], 2); ?></td>
            <td class="<?php echo $med['stock'] <= $med['min_threshold'] ? 'stock-low' : ''; ?>">
                <?php echo $med['stock']; ?>
                <?php if ($med['stock'] <= $med['min_threshold']): ?> ⚠️<?php endif; ?>
            </td>
            <td><?php echo $med['min_threshold']; ?></td>
            <td><?php echo $med['requires_prescription'] ? 'Yes' : 'No'; ?></td>
            <td>
                <a href="edit_medicine.php?id=<?php echo $med['id']; ?>">Edit</a> |
                <a href="delete_medicine.php?id=<?php echo $med['id']; ?>"
                   onclick="return confirm('Delete this medicine?');">Delete</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<?php include '../includes/footer.php'; ?>
