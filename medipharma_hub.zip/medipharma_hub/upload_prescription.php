<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
requireCustomerLogin();

// The upload is only meaningful when the cart really contains a prescription-only
// medicine (decided from the database, not from the browser).
$cartInfo = getCartDetails($pdo);
if (!$cartInfo['needs_rx']) {
    unset($_SESSION['prescription_path']);
    setFlash('warning', 'No prescription is needed: your cart has no prescription-only medicines.');
    redirect(empty($cartInfo['items']) ? 'medicines.php' : 'cart.php');
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCsrf($_POST['csrf_token'] ?? '')) {
        $error = "Your session expired. Please try again.";
    } elseif (!isset($_FILES['prescription']) || !is_array($_FILES['prescription'])) {
        $error = "Please choose a file to upload.";
    } else {
        $file = $_FILES['prescription'];
        // allowed extension => real file types (checked from the file's content, not its name)
        $allowed = [
            'jpg'  => ['image/jpeg'],
            'jpeg' => ['image/jpeg'],
            'png'  => ['image/png'],
            'pdf'  => ['application/pdf'],
        ];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if ($file['error'] === UPLOAD_ERR_NO_FILE) {
            $error = "Please choose a file to upload.";
        } elseif ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) {
            $error = "File is too large (max 5MB).";
        } elseif ($file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
            $error = "Upload failed. Please try again.";
        } elseif (!isset($allowed[$ext])) {
            $error = "Only JPG, PNG, or PDF files are allowed.";
        } elseif ($file['size'] > 5 * 1024 * 1024) {
            $error = "File is too large (max 5MB).";
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime  = $finfo->file($file['tmp_name']);
            if (!in_array($mime, $allowed[$ext], true)) {
                $error = "The file content does not match a JPG, PNG or PDF. Please upload a real prescription image or PDF.";
            } else {
                // Server-generated name: nothing from the visitor's file name is used
                $newName = 'rx_' . $_SESSION['user_id'] . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
                $destination = 'assets/uploads/' . $newName;

                if (move_uploaded_file($file['tmp_name'], __DIR__ . '/' . $destination)) {
                    $_SESSION['prescription_path'] = $destination;
                    $success = "Prescription uploaded successfully. It will be attached to your next order.";
                } else {
                    $error = "Could not save the uploaded file.";
                }
            }
        }
    }

    // When the upload was started from the cart or checkout page, go back there with the result
    $return = $_POST['return'] ?? '';
    if ($return === 'cart' || $return === 'checkout') {
        setFlash($success !== '' ? 'success' : 'error', $success !== '' ? $success : $error);
        redirect($return . '.php');
    }
}

include 'includes/header.php';
?>

<h1>Upload Prescription</h1>
<div class="form-box">
    <p class="text-muted">If any medicine in your cart requires a prescription, upload a clear photo or PDF of it here before checking out.</p>

    <?php if ($error): ?>
        <div class="alert alert-error"><?php echo $error; ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    <?php if (validPrescriptionPath()): ?>
        <div class="alert alert-warning">Current uploaded file: <?php echo clean(basename(validPrescriptionPath())); ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <?php echo csrfField(); ?>
        <label for="prescription">Choose file (JPG, PNG, or PDF)</label>
        <input type="file" id="prescription" name="prescription" accept=".jpg,.jpeg,.png,.pdf" required>
        <button type="submit" class="btn mt-24"><i class="fa-solid fa-upload" aria-hidden="true"></i> Upload</button>
    </form>
    <p class="text-muted mt-24"><a href="cart.php"><i class="fa-solid fa-cart-shopping" aria-hidden="true"></i> Back to cart</a> &nbsp;|&nbsp; <a href="checkout.php">Go to checkout</a></p>
</div>

<?php include 'includes/footer.php'; ?>
