<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
requireCustomerLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && verifyCsrf($_POST['csrf_token'] ?? '')) {
    $medicineId = (int) ($_POST['medicine_id'] ?? 0);
    $qty = max(1, (int) ($_POST['qty'] ?? 1));

    $stmt = $pdo->prepare("SELECT * FROM medicines WHERE id = ?");
    $stmt->execute([$medicineId]);
    $med = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($med && $med['stock'] > 0) {
        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }
        // What is already in the cart plus what is being added must not go above the stock
        $already = isset($_SESSION['cart'][$medicineId]) ? (int) $_SESSION['cart'][$medicineId]['qty'] : 0;
        $newQty  = min($already + $qty, (int) $med['stock']);

        if ($newQty > $already) {
            if ($already > 0) {
                $_SESSION['cart'][$medicineId]['qty'] = $newQty;
            } else {
                $_SESSION['cart'][$medicineId] = [
                    'name'  => $med['name'],
                    'price' => $med['price'],
                    'qty'   => $newQty,
                    'requires_prescription' => $med['requires_prescription'],
                    'image' => $med['image']
                ];
            }
        }
    }
}

// Go back to the same filtered/sorted/paginated list the customer was viewing.
// Only the known shop-page parameters are accepted, so nothing else can be injected.
$back = ['added' => 1];
if (!empty($_POST['return_qs']) && is_string($_POST['return_qs'])) {
    parse_str($_POST['return_qs'], $previous);
    foreach (['q', 'category', 'min_price', 'max_price', 'sort', 'instock', 'page'] as $key) {
        if (isset($previous[$key]) && is_string($previous[$key])) {
            $back[$key] = $previous[$key];
        }
    }
}
redirect('medicines.php?' . http_build_query($back) . '#shop-results');
