<?php
// =========================================================
// cancel_order.php -- a customer cancels one of THEIR OWN orders.
// * POST only, with a CSRF token
// * the order is looked up by id AND the logged-in user's id (no IDOR)
// * only 'pending' / 'processing' orders can be cancelled
// * the status change and the stock restoration happen in one transaction,
//   and the order row is locked, so a repeated request cannot restore stock twice
// * the order record, its items and its prescription file are kept (status change only)
// =========================================================
require_once 'config/db.php';
require_once 'includes/functions.php';
requireCustomerLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('my_orders.php');
}
if (!verifyCsrf($_POST['csrf_token'] ?? '')) {
    setFlash('error', 'Your session expired. Please try again.');
    redirect('my_orders.php');
}

$orderId = (int) ($_POST['order_id'] ?? 0);
$userId  = (int) $_SESSION['user_id'];

try {
    $pdo->beginTransaction();

    // Lock this customer's order row. Someone else's order id simply finds nothing.
    $stmt = $pdo->prepare("SELECT id, status FROM orders WHERE id = ? AND user_id = ? FOR UPDATE");
    $stmt->execute([$orderId, $userId]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        $pdo->rollBack();
        setFlash('error', 'Order not found.');
        redirect('my_orders.php');
    }

    if (!isOrderCancellable($order['status'])) {
        $pdo->rollBack();
        setFlash('error', 'Order #' . $order['id'] . ' cannot be cancelled because it is already ' . $order['status'] . '.');
        redirect('my_orders.php');
    }

    // Change the status (only if it is still cancellable)
    $upd = $pdo->prepare("UPDATE orders SET status = 'cancelled' WHERE id = ? AND user_id = ? AND status IN ('pending','processing')");
    $upd->execute([$orderId, $userId]);
    if ($upd->rowCount() !== 1) {
        throw new RuntimeException('Order status could not be changed.');
    }

    // Put the ordered quantities back into stock (checkout.php took them out)
    $items = $pdo->prepare("SELECT medicine_id, quantity FROM order_items WHERE order_id = ?");
    $items->execute([$orderId]);
    $restore = $pdo->prepare("UPDATE medicines SET stock = stock + ? WHERE id = ?");
    foreach ($items->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $restore->execute([(int) $row['quantity'], (int) $row['medicine_id']]);
    }

    $pdo->commit();
    setFlash('success', 'Order #' . $orderId . ' has been cancelled.');
} catch (Exception $e) {
    if ($pdo->inTransaction()) { $pdo->rollBack(); }
    setFlash('error', 'Something went wrong while cancelling the order. Please try again.');
}

redirect('my_orders.php');
