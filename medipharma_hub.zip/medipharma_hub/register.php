<?php
require_once 'config/db.php';
require_once 'includes/functions.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = clean($_POST['full_name']);
    $email   = clean($_POST['email']);
    $phone   = clean($_POST['phone']);
    $address = clean($_POST['address']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if ($name === '' || $email === '' || $password === '') {
        $error = "Please fill in all required fields.";
    } elseif ($password !== $confirmPassword) {
        // Checked on the server too, so it cannot be skipped by turning JavaScript off
        $error = "Password and Confirm Password do not match.";
    } else {
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);

        if ($stmt->fetch()) {
            $error = "An account with this email already exists.";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare(
                "INSERT INTO users (full_name, email, password, phone, address, role) VALUES (?, ?, ?, ?, ?, 'customer')"
            );
            $stmt->execute([$name, $email, $hashed, $phone, $address]);
            redirect('login.php?registered=1');
        }
    }
}

include 'includes/header.php';
?>

<h1>Create your account</h1>
<div class="form-box">
    <?php if ($error): ?>
        <div class="alert alert-error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="post" id="register-form">
        <label for="full_name">Full name *</label>
        <input type="text" id="full_name" name="full_name" value="<?php echo $name ?? ''; ?>" required>

        <label for="email">Email *</label>
        <input type="email" id="email" name="email" value="<?php echo $email ?? ''; ?>" required>

        <label for="phone">Phone *</label>
        <input type="text" id="phone" name="phone" value="<?php echo $phone ?? ''; ?>" required>

        <label for="address">Delivery address *</label>
        <textarea id="address" name="address" rows="3" required><?php echo $address ?? ''; ?></textarea>

        <label for="password">Password *</label>
        <div class="password-field">
            <input type="password" id="password" name="password" required>
            <button type="button" class="password-toggle" data-target="password"
                    aria-label="Show password" title="Show password" aria-pressed="false">
                <i class="fa-solid fa-eye" aria-hidden="true"></i>
            </button>
        </div>

        <label for="confirm_password">Confirm Password *</label>
        <div class="password-field">
            <input type="password" id="confirm_password" name="confirm_password" required>
            <button type="button" class="password-toggle" data-target="confirm_password"
                    aria-label="Show password" title="Show password" aria-pressed="false">
                <i class="fa-solid fa-eye" aria-hidden="true"></i>
            </button>
        </div>
        <p class="field-error" id="confirm-error" role="alert" hidden></p>

        <button type="submit" class="btn mt-24"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> Register</button>
    </form>
    <p class="text-muted mt-24">Already have an account? <a href="login.php">Log in</a></p>
</div>

<script src="assets/js/auth.js"></script>

<?php include 'includes/footer.php'; ?>
