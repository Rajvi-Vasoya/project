<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
requireCustomerLogin();

// Fetch only the orders of the logged-in customer (latest first)
$stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC, id DESC");
$stmt->execute([$_SESSION['user_id']]);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch the items of all these orders and group them by order id
$itemsByOrder = [];
if ($orders) {
    $stmt = $pdo->prepare(
        "SELECT oi.order_id, oi.quantity, oi.price, m.name
         FROM order_items oi
         JOIN medicines m ON m.id = oi.medicine_id
         JOIN orders o ON o.id = oi.order_id
         WHERE o.user_id = ?
         ORDER BY oi.id"
    );
    $stmt->execute([$_SESSION['user_id']]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $itemsByOrder[$row['order_id']][] = $row;
    }
}

$flash = takeFlash();

include 'includes/header.php';
?>

<h1><i class="fa-solid fa-box-open" aria-hidden="true"></i> My Orders</h1>

<?php if ($flash): ?>
    <div class="alert alert-<?php echo clean($flash['type']); ?>" role="status"><?php echo clean($flash['message']); ?></div>
<?php endif; ?>

<?php if (empty($orders)): ?>
    <p class="text-muted">You have not placed any orders yet. <a href="medicines.php">Browse medicines</a> to get started.</p>
<?php else: ?>

    <?php foreach ($orders as $order): ?>
        <div class="card order-card">
            <div class="order-head">
                <div>
                    <strong>Order #<?php echo $order['id']; ?></strong>
                    <span class="text-muted"> &middot; <?php echo date('d M Y, h:i A', strtotime($order['created_at'])); ?></span>
                </div>
                <?php
                $statusIcons = [
                    'pending'    => 'fa-clock',
                    'processing' => 'fa-gears',
                    'shipped'    => 'fa-truck-fast',
                    'delivered'  => 'fa-circle-check',
                    'cancelled'  => 'fa-circle-xmark',
                ];
                $statusIcon = $statusIcons[$order['status']] ?? 'fa-circle-info';
                ?>
                <span class="status-badge status-<?php echo clean($order['status']); ?>"><i class="fa-solid <?php echo $statusIcon; ?>" aria-hidden="true"></i> <?php echo ucfirst(clean($order['status'])); ?></span>
            </div>

            <table>
                <tr>
                    <th>Medicine</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Subtotal</th>
                </tr>
                <?php foreach (($itemsByOrder[$order['id']] ?? []) as $item): ?>
                    <tr>
                        <td><?php echo clean($item['name']); ?></td>
                        <td>₹<?php echo number_format($item['price'], 2); ?></td>
                        <td><?php echo $item['quantity']; ?></td>
                        <td>₹<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>

            <div class="order-foot">
                <span class="text-muted">Prescription: <?php echo !empty($order['prescription_path']) ? 'Attached' : 'Not attached'; ?></span>
                <strong>Total: ₹<?php echo number_format($order['total_amount'], 2); ?></strong>
            </div>

            <?php if (isOrderCancellable($order['status'])): ?>
                <form method="post" action="cancel_order.php" class="cancel-form"
                      onsubmit="return confirm('Cancel order #<?php echo (int)$order['id']; ?>? This cannot be undone.');">
                    <?php echo csrfField(); ?>
                    <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
                    <button type="submit" class="btn btn-danger btn-small">
                        <i class="fa-solid fa-ban" aria-hidden="true"></i> Cancel Order
                    </button>
                </form>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>

<?php endif; ?>

<?php include 'includes/footer.php'; ?>
